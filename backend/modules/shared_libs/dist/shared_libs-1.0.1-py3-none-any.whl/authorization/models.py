from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel

from .permission_manager import PermissionManager


class CRUDModel(BaseModel):
    create: Optional[str] = ""
    read: Optional[str] = ""
    update: Optional[str] = ""
    delete: Optional[str] = ""


class MasterRegisterRiskScenarioFieldsModel(BaseModel):
    category: CRUDModel
    defaultImpact: CRUDModel
    defaultLikelihood: CRUDModel
    keyRisk: CRUDModel
    mappingToATK: CRUDModel
    mappingToIM8: CRUDModel
    recommendedMitigationMeasures: CRUDModel
    riskScenarioId: CRUDModel
    subcategory: CRUDModel

    def to_list(self, action_key: str) -> List[str]:
        permission_list = []
        field_keys = self.model_fields.keys()
        for k in field_keys:
            field_model: CRUDModel = getattr(self, k, None)
            if not field_model:
                continue
            permission: str = getattr(field_model, action_key, "")
            if not permission:
                continue
            permission_list.append(f"{permission}")
        return permission_list


class MasterRegisterRiskScenarioPermissionModel(CRUDModel):
    fields: MasterRegisterRiskScenarioFieldsModel


class MasterRegisterPermissionFieldsModel(BaseModel):
    risk_scenarios: MasterRegisterRiskScenarioPermissionModel

    def to_list(self, action_key: str) -> List[str]:
        permission_list = []
        field_keys = self.model_fields.keys()
        for k in field_keys:
            field_model: CRUDModel = getattr(self, k, None)
            if not field_model:
                continue
            permission: str = getattr(field_model, action_key, "")
            if not permission:
                continue
            permission_list.append(f"{permission}")
        return permission_list


class MasterRegisterPermissionModel(CRUDModel):
    fields: MasterRegisterPermissionFieldsModel


class ProjectRegisterRiskScenarioFieldsModel(MasterRegisterRiskScenarioFieldsModel):
    acceptedBy: CRUDModel
    acceptanceReportedBy: CRUDModel
    acceptanceReportedDate: CRUDModel
    actualMitigationMeasures: CRUDModel
    knowledgebaseSource: CRUDModel
    location: CRUDModel
    priority: CRUDModel
    remarks: CRUDModel
    treatmentComments: CRUDModel
    reviewComments: CRUDModel
    residualImpact: CRUDModel
    residualLikelihood: CRUDModel
    responseAndRecoverPlan: CRUDModel
    sourceRiskScenarioId: CRUDModel
    status: CRUDModel
    tags: CRUDModel

    def to_list(self, action_key: str) -> List[str]:
        permission_list = []
        field_keys = self.model_fields.keys()
        for k in field_keys:
            field_model: CRUDModel = getattr(self, k, None)
            if not field_model:
                continue
            permission: str = getattr(field_model, action_key, "")
            if not permission:
                continue
            permission_list.append(f"{permission}")
        return permission_list


class ProjectRegisterRiskScenarioPermissionModel(CRUDModel):
    fields: ProjectRegisterRiskScenarioFieldsModel


class ProjectRegisterPermissionFieldsModel(BaseModel):
    risk_scenarios: ProjectRegisterRiskScenarioPermissionModel

    def to_list(self, action_key: str) -> List[str]:
        permission_list = []
        field_keys = self.model_fields.keys()
        for k in field_keys:
            field_model: CRUDModel = getattr(self, k, None)
            if not field_model:
                continue
            permission: str = getattr(field_model, action_key, "")
            if not permission:
                continue
            permission_list.append(f"{permission}")
        return permission_list


class ProjectRegisterPermissionModel(CRUDModel):
    fields: ProjectRegisterPermissionFieldsModel


class ProjectPermissionFieldsModel(BaseModel):
    project_status: CRUDModel

    def to_list(self, action_key: str) -> List[str]:
        permission_list = []
        field_keys = self.model_fields.keys()
        for k in field_keys:
            field_model: CRUDModel = getattr(self, k, None)
            if not field_model:
                continue
            permission: str = getattr(field_model, action_key, "")
            if not permission:
                continue
            permission_list.append(f"{permission}")
        return permission_list


class ProjectPermissionModel(CRUDModel):
    fields: ProjectPermissionFieldsModel


class PermissionModel(BaseModel):
    admin_project: CRUDModel
    admin_resource_tag: CRUDModel
    admin_token: CRUDModel
    admin_user: CRUDModel
    master_attack_search: CRUDModel
    master_attack: CRUDModel
    master_cq_template: CRUDModel
    master_cq: CRUDModel
    master_diagram_template: CRUDModel
    master_register_log: CRUDModel
    master_register: MasterRegisterPermissionModel
    node_tosca: CRUDModel
    project_cq_submitted: CRUDModel
    project_cq_template: CRUDModel
    project_cq: CRUDModel
    project_ct: CRUDModel
    project_diagram_file_module: CRUDModel
    project_diagram_file_terraform: CRUDModel
    project_diagram: CRUDModel
    project_register_history: CRUDModel
    project_register_log: CRUDModel
    project_register: ProjectRegisterPermissionModel
    project: ProjectPermissionModel
    resource_tag: CRUDModel


permission_manager = PermissionManager()
user_permission_dict = permission_manager.user_permission_dict
permission_model = PermissionModel(**user_permission_dict)

__all__ = [
    "CRUDModel",
    "MasterRegisterPermissionFieldsModel",
    "MasterRegisterPermissionModel",
    "MasterRegisterRiskScenarioFieldsModel",
    "MasterRegisterRiskScenarioPermissionModel",
    "PermissionModel",
    "ProjectPermissionFieldsModel",
    "ProjectPermissionModel",
    "ProjectRegisterPermissionFieldsModel",
    "ProjectRegisterPermissionModel",
    "ProjectRegisterRiskScenarioFieldsModel",
    "ProjectRegisterRiskScenarioPermissionModel",
    "permission_model",
]
