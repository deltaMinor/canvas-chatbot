from enum import Enum


class ADTemplate(Enum):
    templateId = "templateId"
    templateName = "templateName"
    templateData = "templateData"


class AttackDocType(Enum):
    attack_ics_docs = "attack_ics_docs"
    attack_mobile_docs = "attack_mobile_docs"
    attack_enterprise_docs = "attack_enterprise_docs"
    attack_docs = "attack_docs"


class AttackDomain(Enum):
    ics = "ics"
    mobile = "mobile"
    enterprise = "enterprise"


class AttackObjectType(Enum):
    tactic = "tactic"
    technique = "technique"
    subtechnique = "subtechnique"
    dataSource = "dataSource"
    mitigation = "mitigation"
    group = "group"
    software = "software"
    campaign = "campaign"


class AttackObjectTypeLabel(Enum):
    tactic = "Tactic"
    technique = "Technique"
    subtechnique = "Sub-technique"
    dataSource = "Data Source"
    mitigation = "Mitigation"
    group = "Group"
    software = "Software"
    campaign = "Campaign"
    matrix = "Matrix"
    relationship = "Relationship"
    collection = "Collection"
    dataComponent = "Data Component"
    identity = "Identity"
    markingDefinition = "Marking Definition"
    procedure = "Procedure"


class CanvasType(Enum):
    architecture = "architecture"
    custom = "custom"
    data_flow = "data_flow"
    example = "example"
    template = "template"


class CanvasNodeType(Enum):
    architecture = "architecture"
    data_flow = "data_flow"


class CanvasNodeVariantType(Enum):
    clusterNode = "clusterNode"
    infoNode = "infoNode"


class CardFieldId(Enum):
    card_data = "field_Zz8qcXRmTdRthKaSaSsYGp"
    card_devices = "field_Beug2fybTozsC4q9GzrisZ"
    card_feature = "field_kjoQLrFNiwtPd6PSFiF4ui"
    card_intent = "field_SQgayC4tL9q294ao54XnYD"
    card_interface = "field_nd6pU88Fpe5mtLkyHMTnPW"
    card_outcome = "field_TNPsydHStdtNvySMqfV8qF"
    card_title = "field_RcTZUir6t69LEoJv9ipQsQ"
    card_users = "field_KxsU6BvQmFPtXRcH44ZhKj"


class KnowledgebaseSource(Enum):
    attack = "MITRE ATT&CK"
    masterRiskRegister = "Master Risk Register"


class Collection(Enum):
    # ad_svg_files = "ad_svg_files"
    feedback_form = "feedback_form"
    kb_attack_bundle = "kb_attack_bundle"
    kb_attack_enterprise = "kb_attack_enterprise"
    kb_attack_ics = "kb_attack_ics"
    kb_attack_mobile = "kb_attack_mobile"
    kb_generation_rule = "kb_generation_rule"
    kb_generation_rules_library = "kb_generation_rules_library"
    kb_priority_rules = "kb_priority_rules"
    kb_question_to_model = "kb_question_to_model"
    kb_register_mapping = "kb_register_mapping"
    master_ad_template = "master_ad_template"
    master_cq = "master_cq"
    master_cq_template = "master_cq_template"
    master_register = "master_register"
    master_register_logs = "master_register_logs"
    project_ad = "project_ad"
    project_ad_file_module = "project_ad_file_module"
    project_ad_file_terraform = "project_ad_file_terraform"
    project_cq = "project_cq"
    project_cq_submitted = "project_cq_submitted"
    project_cq_template = "project_cq_template"
    project_register = "project_register"
    project_register_history = "project_register_history"
    project_register_logs = "project_register_logs"
    project_templates = "project_templates"
    projects = "projects"
    resource_tag = "resource_tag"
    tokens = "tokens"
    users = "users"


class CQFieldId(Enum):
    user_story_card = "field_aYTgbRTobNfeTx8qfgNaYX"


class DefaultGroup(Enum):
    Placeholder = "Placeholder"
    Unassigned = "Unassigned"


class GenerationRules(Enum):
    rules = "rules"


class Group(Enum):
    metadata = "metadata"
    group_id = "group_id"
    group_name = "group_name"
    created = "created"
    group_project_count = "group_project_count"


class JWT(Enum):
    access_token = "access_token"
    scope = "scope"
    token_type = "token_type"
    expires_in = "expires_in"
    expires_at = "expires_at"
    authorization = "HTTP_AUTHORIZATION"
    iss = "iss"
    iat = "iat"
    exp = "exp"
    jti = "jti"


class MasterCQ(Enum):
    schema_ = "schema_"
    dependentFields = "dependentFields"
    idList = "idList"
    initialValues = "initialValues"
    metadata = "metadata"
    sections = "sections"


class MasterRegister(Enum):
    schema_ = "schema_"
    category_options = "category_options"
    risk_info = "risk_info"
    risk_scenarios = "risk_scenarios"
    subcategory_options = "subcategory_options"


class MasterTemplate(Enum):
    schema_ = "schema_"
    conception_questionnaire_templates = "conception_questionnaire_templates"


class Metadata(Enum):
    created_on = "created_on"
    modified_on = "modified_on"
    submitted_on = "submitted_on"


class MetadataField(Enum):
    timestamp = "timestamp"
    user_id = "user_id"
    username = "username"
    data = "data"


class Parameter(Enum):
    keyName = "keyName"
    keyMeaning = "keyMeaning"
    parameters = "parameters"


class Project(Enum):
    architecture_diagram = "architecture_diagram"
    conception_questionnaire = "conception_questionnaire"
    conception_template = "conception_template"
    metadata = "metadata"
    project_group = "project_group"
    project_group_id = "project_group_id"
    project_id = "project_id"
    project_name = "project_name"
    project_register = "project_register"
    resource_tags = "resource_tags"
    user_count = "user_count"


class ProjectAD(Enum):
    canvas = "canvas"
    canvas_views = "canvas_views"
    card_nodes = "card_nodes"
    project_id = "project_id"


class ProjectADCanvas(Enum):
    canvas_data = "canvas_data"
    canvas_data_history = "canvas_data_history"
    canvas_data_index = "canvas_data_index"
    canvas_id = "canvas_id"


class ProjectCQ(Enum):
    dependentFields = "dependentFields"
    initialValues = "initialValues"
    metadata = "metadata"
    project_id = "project_id"
    saved = "saved"
    submitted = "submitted"


class ProjectRegister(Enum):
    attack_paths = "attack_paths"
    cache_risk_scenarios = "cache_risk_scenarios"
    category_options = "category_options"
    project_id = "project_id"
    risk_info = "risk_info"
    risk_scenarios = "risk_scenarios"
    schema_ = "schema_"
    subcategory_options = "subcategory_options"


class ProjectRegisterHistory(Enum):
    project_id = "project_id"
    design_stats = "design_stats"
    history = "history"
    # im8_stats = "im8_stats"
    last_timestamp = "last_timestamp"
    total_stats = "total_stats"
    compliance_stats = "compliance_stats"


class ProjectTemplate(Enum):
    conception_questionnaire_templates = "conception_questionnaire_templates"
    project_id = "project_id"
    schema_ = "schema_"


class QuestionnaireData(Enum):
    schema_ = "schema_"
    metadata = "metadata"
    values = "values"


class RegisterGenerationRequest(Enum):
    project = "project"
    risk_scenarios = "risk_scenarios"
    generation_rules = "generation_rules"


class RegisterType(Enum):
    master_register = "master_register"
    project_register = "project_register"


class RiskRating(Enum):
    One = ("Low",)
    Two = ("Medium",)
    Three = ("Medium High",)
    Four = ("High",)
    Five = ("Very High",)
    Unspecified = ""


class Role(Enum):
    developer = "developer"
    projectManager = "projectManager"
    securityConsultant = "securityConsultant"
    manager = "manager"


class ScenarioTags(Enum):
    focused = "Focused"
    questionnaireUpdate = "Questionnaire Update"
    masterScenarioUpdate = "Master Risk Scenario Update"
    deprecated = "Deprecated"


class TokenKey(Enum):
    user_id = "user_id"
    username = "username"
    hashed_token = "hashed_token"
    token_type = "token_type"
    valid = "valid"
    metadata = "metadata"


class TokenType(Enum):
    login = "login"
    refresh = "refresh"
    resetPassword = "resetPassword"


class User(Enum):
    email = "email"
    entitlements = "entitlements"
    group_id_list = "group_id_list"
    groups = "groups"
    is_logged_in = "is_logged_in"
    is_superuser = "is_superuser"
    metadata = "metadata"
    notifications = "notifications"
    password = "password"
    project_id_list = "project_id_list"
    roles = "roles"
    user_id = "user_id"
    user_id_list = "user_id_list"
    user_status = "user_status"
    username = "username"


class UserStatus(Enum):
    active = "active"
    pending = "pending"
    disabled = "disabled"


class StixObjectType(Enum):
    attack_action = "attack-action"
    attack_asset = "attack-asset"
    attack_condition = "attack-condition"
    attack_flow = "attack-flow"
    attack_operator = "attack-operator"
    attack_pattern = "attack-pattern"
    extension_definition = "extension-definition"
    grouping = "grouping"
    identity = "identity"


class StixExtensionType(Enum):
    new_sdo = "new-sdo"
    new_sco = "new-sco"
    property_extension = "property-extension"


class StixScopeType(Enum):
    incident = "incident"
    campaign = "campaign"
    threat_actor = "threat-actor"
    malware = "malware"
    other = "other"


class StixOperatorType(Enum):
    AND = "AND"
    OR = "OR"


class KnowledgeBaseSource(Enum):
    attack = "ATT&CK"
    master_risk_register = "Master Risk Register"
