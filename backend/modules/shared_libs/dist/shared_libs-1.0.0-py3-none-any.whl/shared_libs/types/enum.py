from enum import Enum


class ADTemplate(Enum):
    templateId = "templateId"
    templateName = "templateName"
    templateData = "templateData"


class AttackDocType(Enum):
    attack_ics_docs = "attack_ics_docs"
    attack_mobile_docs = "attack_mobile_docs"
    attack_enterprise_docs = "attack_enterprise_docs"
    attack_docs = "attack_docs"


class AttackDomain(Enum):
    ics = "ics"
    mobile = "mobile"
    enterprise = "enterprise"


class AttackObjectType(Enum):
    tactic = "tactic"
    technique = "technique"
    subtechnique = "subtechnique"
    dataSource = "dataSource"
    mitigation = "mitigation"
    group = "group"
    software = "software"
    campaign = "campaign"


class AttackObjectTypeLabel(Enum):
    tactic = "Tactic"
    technique = "Technique"
    subtechnique = "Sub-technique"
    dataSource = "Data Source"
    mitigation = "Mitigation"
    group = "Group"
    software = "Software"
    campaign = "Campaign"
    matrix = "Matrix"
    relationship = "Relationship"
    collection = "Collection"
    dataComponent = "Data Component"
    identity = "Identity"
    markingDefinition = "Marking Definition"
    procedure = "Procedure"


class CanvasType(Enum):
    architecture = "architecture"
    custom = "custom"
    data_flow = "data_flow"
    example = "example"
    template = "template"


class CardFieldId(Enum):
    card_data = "field_Zz8qcXRmTdRthKaSaSsYGp"
    card_devices = "field_Beug2fybTozsC4q9GzrisZ"
    card_feature = "field_kjoQLrFNiwtPd6PSFiF4ui"
    card_intent = "field_SQgayC4tL9q294ao54XnYD"
    card_interface = "field_nd6pU88Fpe5mtLkyHMTnPW"
    card_outcome = "field_TNPsydHStdtNvySMqfV8qF"
    card_title = "field_RcTZUir6t69LEoJv9ipQsQ"
    card_users = "field_KxsU6BvQmFPtXRcH44ZhKj"


class Category(Enum):
    attack = "ATT&CK"
    im8 = "IM8"
    riskregister = "Master Risk Register"


class Collection(Enum):
    ad_canvas = "ad_canvas"
    ad_data_flow = "ad_data_flow"
    ad_data_flow_files = "ad_data_flow_files"
    ad_module_files = "ad_module_files"
    ad_network_files = "ad_network_files"
    ad_svg_files = "ad_svg_files"
    ad_terraform_files = "ad_terraform_files"
    architecture_diagram = "architecture_diagram"
    architecture_diagram_template = "architecture_diagram_template"
    attack_enterprise = "attack_enterprise"
    attack_ics = "attack_ics"
    attack_mobile = "attack_mobile"
    generation_rule = "generation_rule"
    generation_rules = "generation_rules"
    generation_rules_library = "generation_rules_library"
    groups = "groups"
    master_cq = "master_cq"
    master_cq_template = "master_cq_template"
    master_register = "master_register"
    master_register_logs = "master_register_logs"
    priority_rules = "priority_rules"
    project_cq = "project_cq"
    project_cq_submitted = "project_cq_submitted"
    project_cq_template = "project_cq_template"
    project_register = "project_register"
    project_register_history = "project_register_history"
    project_register_logs = "project_register_logs"
    project_templates = "project_templates"
    projects = "projects"
    question_to_model = "question_to_model"
    questionnaire = "questionnaire"
    register_mapping = "register_mapping"
    resource_tag = "resource_tag"
    tokens = "tokens"
    users = "users"


class CQFieldId(Enum):
    user_story_card = "field_aYTgbRTobNfeTx8qfgNaYX"


class DefaultGroup(Enum):
    Placeholder = "Placeholder"
    Unassigned = "Unassigned"


class GenerationRules(Enum):
    rules = "rules"


class Group(Enum):
    metadata = "metadata"
    group_id = "group_id"
    group_name = "group_name"
    created = "created"
    group_project_count = "group_project_count"


class JWT(Enum):
    access_token = "access_token"
    scope = "scope"
    token_type = "token_type"
    expires_in = "expires_in"
    expires_at = "expires_at"
    authorization = "HTTP_AUTHORIZATION"
    iss = "iss"
    iat = "iat"
    exp = "exp"
    jti = "jti"


class MasterCQ(Enum):
    schema_ = "schema_"
    dependentFields = "dependentFields"
    idList = "idList"
    initialValues = "initialValues"
    metadata = "metadata"
    sections = "sections"


class MasterRegister(Enum):
    schema_ = "schema_"
    category_options = "category_options"
    risk_info = "risk_info"
    risk_scenarios = "risk_scenarios"
    subcategory_options = "subcategory_options"


class MasterTemplate(Enum):
    schema_ = "schema_"
    conception_questionnaire_templates = "conception_questionnaire_templates"


class Metadata(Enum):
    created_on = "created_on"
    modified_on = "modified_on"
    submitted_on = "submitted_on"


class MetadataField(Enum):
    timestamp = "timestamp"
    user_id = "user_id"
    username = "username"
    data = "data"


class Parameter(Enum):
    keyName = "keyName"
    keyMeaning = "keyMeaning"
    parameters = "parameters"


class Project(Enum):
    architecture_diagram = "architecture_diagram"
    conception_questionnaire = "conception_questionnaire"
    conception_template = "conception_template"
    metadata = "metadata"
    project_group = "project_group"
    project_group_id = "project_group_id"
    project_id = "project_id"
    project_name = "project_name"
    project_register = "project_register"
    resource_tags = "resource_tags"
    user_count = "user_count"


class ProjectAD(Enum):
    canvas = "canvas"
    canvas_views = "canvas_views"
    card_nodes = "card_nodes"
    project_id = "project_id"


class ProjectADCanvas(Enum):
    canvas_data = "canvas_data"
    canvas_data_history = "canvas_data_history"
    canvas_data_index = "canvas_data_index"
    canvas_id = "canvas_id"
    

class ProjectCQ(Enum):
    dependentFields = "dependentFields"
    initialValues = "initialValues"
    metadata = "metadata"
    project_id = "project_id"
    saved = "saved"
    submitted = "submitted"


class ProjectRegister(Enum):
    attack_paths = "attack_paths"
    cache_risk_scenarios = "cache_risk_scenarios"
    category_options = "category_options"
    project_id = "project_id"
    risk_info = "risk_info"
    risk_scenarios = "risk_scenarios"
    schema_ = "schema_"
    subcategory_options = "subcategory_options"


class ProjectRegisterHistory(Enum):
    project_id = "project_id"
    attack_stats = "attack_stats"
    history = "history"
    im8_stats = "im8_stats"
    last_timestamp = "last_timestamp"
    overall_stats = "overall_stats"
    rr_stats = "rr_stats"


class ProjectTemplate(Enum):
    conception_questionnaire_templates = "conception_questionnaire_templates"
    project_id = "project_id"
    schema_ = "schema_"


class QuestionnaireData(Enum):
    schema_ = "schema_"
    metadata = "metadata"
    values = "values"


class RegisterGenerationRequest(Enum):
    project = "project"
    risk_scenarios = "risk_scenarios"
    generation_rules = "generation_rules"


class RegisterType(Enum):
    master_register = "master_register"
    project_register = "project_register"


class RiskRating(Enum):
    One = ("Low",)
    Two = ("Medium",)
    Three = ("Medium High",)
    Four = ("High",)
    Five = ("Very High",)
    Unspecified = ""


class Role(Enum):
    developer = "developer"
    projectManager = "projectManager"
    securityConsultant = "securityConsultant"
    manager = "manager"


class ScenarioTags(Enum):
    focused = "Focused"
    questionnaireUpdate = "Questionnaire Update"
    masterScenarioUpdate = "Master Risk Scenario Update"
    deprecated = "Deprecated"


class TokenKey(Enum):
    user_id = "user_id"
    username = "username"
    hashed_token = "hashed_token"
    token_type = "token_type"
    valid = "valid"
    metadata = "metadata"


class TokenType(Enum):
    login = "login"
    refresh = "refresh"
    resetPassword = "resetPassword"


class User(Enum):
    email = "email"
    entitlements = "entitlements"
    group_id_list = "group_id_list"
    groups = "groups"
    is_logged_in = "is_logged_in"
    is_superuser = "is_superuser"
    metadata = "metadata"
    notifications = "notifications"
    password = "password"
    project_id_list = "project_id_list"
    roles = "roles"
    user_id = "user_id"
    user_id_list = "user_id_list"
    user_status = "user_status"
    username = "username"


class UserStatus(Enum):
    active = "active"
    pending = "pending"
    disabled = "disabled"


class StixObjectType(Enum):
    attack_action = "attack-action"
    attack_asset = "attack-asset"
    attack_condition = "attack-condition"
    attack_flow = "attack-flow"
    attack_operator = "attack-operator"
    attack_pattern = "attack-pattern"
    extension_definition = "extension-definition"
    grouping = "grouping"
    identity = "identity"


class StixExtensionType(Enum):
    new_sdo = "new-sdo"
    new_sco = "new-sco"
    property_extension = "property-extension"


class StixScopeType(Enum):
    incident = "incident"
    campaign = "campaign"
    threat_actor = "threat-actor"
    malware = "malware"
    other = "other"


class StixOperatorType(Enum):
    AND = "AND"
    OR = "OR"
