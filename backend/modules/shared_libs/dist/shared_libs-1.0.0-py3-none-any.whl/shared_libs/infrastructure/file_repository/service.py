import datetime
from typing import List

from gridfs import GridOut

from ... import lib_config
from ...decorators.exception import raise_exception
from ...decorators.validation import verify_params
from ...exceptions.api_exceptions import InternalServerError
from ...infrastructure.file_repository.helper import FileRepositoryHelper
from ...lib.file_manager import FileManager
from ...logger.app_logger import logger
from ..database_client.file_repository_collection import FileRepositoryCollection

TZINFO = lib_config.TZINFO


class FileRepository(FileRepositoryHelper):
    """
    A class for handling operations related to a file repository.

    This class extends the FileRepositoryHelper class and provides methods to find a single file, find multiple files, insert a single file, and delete multiple files.

    Attributes:
        collection (FileRepositoryCollection): The collection of files in the repository.
        MAX_FILE_VERSIONS (int): The maximum number of versions of a file.
    """

    MAX_FILE_VERSIONS = 1

    def __init__(
        self,
        collection: FileRepositoryCollection,
    ):
        """
        Constructs all the necessary attributes for the FileRepository object.

        Args:
            collection (FileRepositoryCollection): The collection of files that this repository will use.
        """
        super().__init__(collection=collection)
        self.collection = collection

    @raise_exception("Failed to retrieve latest file from database.")
    @verify_params(key_list=["query_dict"])
    def find_single_file(
        self,
        query_dict: dict,
        **kwargs,
    ) -> dict | None:
        """
        Finds a single file in the repository.

        Args:
            query_dict (dict): The query to use to find the file.
            **kwargs: Additional keyword arguments.

        Returns:
            dict | None: The found file, or None if no file was found.
        """
        filename = query_dict.get("filename")
        if filename is None:
            raise InternalServerError("filename is undefined.")

        if not self.is_file_exist(query_dict):
            return

        return self.get_formatted_file(
            file=self.get_latest_file(**query_dict),
            project_id=query_dict.get("project_id"),
        )

    @raise_exception("Failed to retrieve latest files from database.")
    @verify_params(key_list=["query_dict"])
    def find_multiple_files(
        self,
        query_dict: dict,
        **kwargs,
    ) -> List[dict]:
        """
        Finds multiple files in the repository.

        Args:
            query_dict (dict): The query to use to find the files.
            **kwargs: Additional keyword arguments.

        Returns:
            List[dict]: The found files.
        """
        files = []
        filenames = query_dict.get("filenames", self.collection.list())
        for f in filenames:
            query_dict["filename"] = f
            db_file = self.find_single_file(
                query_dict=query_dict,
            )
            if not db_file:
                continue
            files.append(db_file)
        return files

    @raise_exception("Failed to insert file in database.")
    @verify_params(key_list=["query_dict", "decoded_file", "user_info"])
    def insert_single_file(
        self,
        query_dict: dict,
        decoded_file: str,
        user_info: dict,
        **kwargs,
    ):
        """
        Inserts a single file into the repository.

        Args:
            query_dict (dict): The query to use to insert the file.
            decoded_file (str): The decoded file to insert.
            user_info (dict): The user information.
            **kwargs: Additional keyword arguments.

        Returns:
            tuple: The file ID and the number of versions of the file.
        """
        project_id = query_dict.get("project_id")
        filename = query_dict.get("filename")

        file_count = self.check_if_file_exist(
            query_dict=query_dict,
            filename=filename,
            MAX_FILE_VERSIONS=kwargs.get("MAX_FILE_VERSIONS", self.MAX_FILE_VERSIONS),
        )

        timestamp = datetime.datetime.now(TZINFO)
        metadata_field = self.get_metadata_field(timestamp, user_info)

        file_bytes = FileManager.get_file_bytes(decoded_file=decoded_file)
        collection_put_body = {
            "data": file_bytes,
            "filename": filename,
            "metadata": {"created_on": metadata_field},
        }
        if project_id:
            collection_put_body["project_id"] = project_id
        file_id = self.collection.put(**collection_put_body)
        file_count += 1

        logger.debug(f"Total file versions in storage: {file_count}")
        if file_count >= self.MAX_FILE_VERSIONS:
            logger.warning(
                f"File has reached the maximum versions allowable. On subsequent uploads, the oldest version will be overwritten."
            )
        return file_id, file_count

    @raise_exception("Failed to delete files in database.")
    @verify_params(key_list=["query_dict"])
    def delete_multiple_files(
        self,
        query_dict: dict,
        **kwargs,
    ):
        """
        Deletes multiple files from the repository.

        This method finds all files that match the provided query and deletes them from the repository.

        Args:
            query_dict (dict): The query to use to find the files to delete.
            **kwargs: Additional keyword arguments.
        """
        for _ in self.collection.find(filter=query_dict):
            grid_out: GridOut = _
            self.collection.delete(file_id=grid_out._id)
