from typing import Any, Dict, List, Optional

from pydantic import BaseModel

from .base_models import (
    ADTemplateBaseModel,
    CanvasBaseModel,
    CanvasCardNodeBaseModel,
    CanvasViewBaseModel,
    ConceptionTemplateBaseModel,
    DatabaseModel,
    JwtDictModel,
    MasterRiskScenario,
    ProjectBaseModel,
    ProjectRegisterStatsBaseModel,
    ProjectRiskScenario,
    QuestionnaireSectionModel,
    QuestionnaireValue,
    QuestionPreConditionProperties,
    RegisterBaseModel,
    RegisterLogsBaseModel,
    RegisterRefBaseModel,
    RegisterStatsDataModel,
    ResourceTagBaseModel,
    UserBaseModel,
)


class UserModel(UserBaseModel, DatabaseModel):
    pass


class UserAdminModel(UserModel):
    is_logged_in: Optional[bool] = False


class AuthenticationModel(BaseModel):
    decoded_token: JwtDictModel
    encoded_token: str
    unique_permissions: List[str]
    user: UserModel


class MasterDiagramTemplateModel(ADTemplateBaseModel, DatabaseModel):
    pass


class QuestionnaireCoreModel(DatabaseModel):
    schema_: float


class QuestionnaireModel(QuestionnaireCoreModel):
    dependentFields: Optional[Dict[str, QuestionPreConditionProperties]] = None
    initialValues: Optional[QuestionnaireValue] = None
    sections: List[QuestionnaireSectionModel]


class MasterCQModel(QuestionnaireModel):
    pass


class ProjectCQModel(QuestionnaireModel):
    project_id: str
    values: Optional[QuestionnaireValue] = None


class ProjectCQSubmittedModel(QuestionnaireModel):
    cq_version_id: Optional[str] = ""
    project_id: str
    values: Optional[QuestionnaireValue] = None


class MasterCQTemplateModel(DatabaseModel):
    schema_: float
    conception_questionnaire_templates: List[ConceptionTemplateBaseModel]


class ProjectCQTemplateModel(DatabaseModel):
    project_id: str
    schema_: float
    conception_questionnaire_templates: List[ConceptionTemplateBaseModel]


class MasterRegisterModel(DatabaseModel, RegisterBaseModel):
    risk_scenarios: List[MasterRiskScenario]


class ProjectModel(ProjectBaseModel, DatabaseModel):
    pass


class ProjectADModel(DatabaseModel):
    project_id: str
    canvas: Optional[CanvasBaseModel] = None
    canvas_views: Optional[List[CanvasViewBaseModel]] = []
    card_nodes: Optional[List[CanvasCardNodeBaseModel]] = []


class ProjectAdminModel(ProjectModel):
    resource_tag_names: List[str]


class ProjectRegisterHistoryModel(DatabaseModel):
    project_id: str
    last_timestamp: Optional[str] = ""
    history: Optional[List[ProjectRegisterStatsBaseModel]] = []
    attack_stats: Optional[RegisterStatsDataModel] = None
    risk_register_stats: Optional[RegisterStatsDataModel] = None
    im8_stats: Optional[RegisterStatsDataModel] = None
    overall_stats: Optional[RegisterStatsDataModel] = None


class ProjectRegisterModel(DatabaseModel, RegisterBaseModel):
    project_id: str
    attack_paths: Optional[List[Any]] = []
    cache_risk_scenarios: Optional[List[ProjectRiskScenario]] = []
    risk_scenarios: Optional[List[ProjectRiskScenario]] = []
    ref: Optional[RegisterRefBaseModel] = None


class RegisterLogsModel(DatabaseModel, RegisterLogsBaseModel):
    pass


class ResourceTagAdminModel(ResourceTagBaseModel, DatabaseModel):
    parent_tag_name: Optional[str] = ""
    root_tag_name: Optional[str] = ""


class ResourceTagModel(ResourceTagBaseModel, DatabaseModel):
    pass


class ResourceTagTreeModel(ResourceTagModel):
    parent_nodes: Optional[List[str]] = []
    child_nodes: Optional[List[str]] = []


class TokenModel(DatabaseModel):
    user_id: str
    username: str
    hashed_token: str
    token_type: str
    valid: bool
