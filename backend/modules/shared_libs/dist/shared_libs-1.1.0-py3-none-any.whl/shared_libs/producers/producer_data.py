producer_data_attack_bundle = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_attack_bundle_task",
            "find_multiple": "rr.create_get_attack_bundles_task",
            "update_single": "rr.create_insert_attack_bundle_task",
            "delete_multiple": "rr.create_delete_attack_bundles_task",
        },
        "task_key_dict": {
            "find_single": "attack_bundle",
            "find_multiple": "attack_bundles",
        },
    },
}

producer_data_ad_template = {
    "task_queue": "ad_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "ad.create_get_ad_template_task",
            "find_multiple": "ad.create_get_ad_templates_task",
        },
        "task_key_dict": {
            "find_single": "ad_template",
            "find_multiple": "ad_templates",
        },
    },
}

producer_data_attack_enterprise = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_attack_enterprise_task",
            "find_multiple": "rr.create_get_attack_enterprise_list_task",
        },
        "task_key_dict": {
            "find_single": "attack_enterprise",
            "find_multiple": "attack_enterprise_list",
        },
    },
}

producer_data_attack_ics = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_attack_ics_task",
            "find_multiple": "rr.create_get_attack_ics_list_task",
        },
        "task_key_dict": {
            "find_single": "attack_ics",
            "find_multiple": "attack_ics_list",
        },
    },
}

producer_data_attack_mobile = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_attack_mobile_task",
            "find_multiple": "rr.create_get_attack_mobile_list_task",
        },
        "task_key_dict": {
            "find_single": "attack_mobile",
            "find_multiple": "attack_mobile_list",
        },
    },
}

producer_data_authentication = {
    "task_queue": "authentication_queue",
    "task_mappings": {
        "task_name_dict": {
            "verify_token": "auth.create_verify_token_task",
            "delete_all_tokens": "auth.create_delete_all_tokens_task",
        },
        "task_key_dict": {},
    },
}

producer_data_generation_rule = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_generation_rule_task",
        },
        "task_key_dict": {
            "find_single": "generation_rule",
        },
    },
}

producer_data_generation_rules_library = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_generation_rules_library_task",
        },
        "task_key_dict": {
            "find_single": "generation_rules_library",
        },
    },
}

producer_data_priority_rules = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_priority_rules_task",
        },
        "task_key_dict": {
            "find_single": "priority_rules",
        },
    },
}

producer_data_group = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_group_task",
            "find_multiple": "application.create_get_groups_task",
            "update_single": "application.create_update_group_task",
            "update_single_list": "application.create_update_group_list_task",
            "delete_multiple": "application.create_delete_groups_task",
        },
        "task_key_dict": {
            "find_single": "group",
            "find_multiple": "groups",
        },
    },
}

producer_data_master_cq = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_master_cq_task",
            "update_single": "application.create_update_master_cq_task",
        },
        "task_key_dict": {
            "find_single": "master_cq",
        },
    },
}

producer_data_master_cq_template = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_master_cq_template_task",
            "update_single": "application.create_update_master_cq_template_task",
        },
        "task_key_dict": {
            "find_single": "master_cq_template",
        },
    },
}

producer_data_master_register = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_master_register_task",
            "find_multiple": "rr.create_get_master_registers_task",
            "update_single": "rr.create_update_master_register_task",
        },
        "task_key_dict": {
            "find_single": "master_register",
            "find_multiple": "master_registers",
        },
    },
}

producer_data_master_register_logs = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_multiple": "rr.create_get_master_register_log_list_task",
        },
        "task_key_dict": {
            "find_multiple": "master_register_log_list",
        },
    },
}

producer_data_project_ad = {
    "task_queue": "ad_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "ad.create_get_project_ad_task",
            "find_multiple": "ad.create_get_project_ads_task",
            "update_single": "ad.create_update_project_ad_task",
            "update_single_list": "ad.create_update_project_ad_list_task",
            "delete_multiple": "ad.create_delete_project_ads_task",
        },
        "task_key_dict": {
            "find_single": "project_ad",
            "find_multiple": "project_ads",
        },
    },
}

producer_data_project_cq = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_project_cq_task",
            "find_multiple": "application.create_get_project_cqs_task",
            "update_single": "application.create_update_project_cq_task",
            "update_single_list": "application.create_update_project_cq_list_task",
            "delete_multiple": "application.create_delete_project_cqs_task",
        },
        "task_key_dict": {
            "find_single": "project_cq",
            "find_multiple": "project_cqs",
        },
    },
}

producer_data_project_cq_submitted = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_project_cq_submitted_task",
            "update_single": "application.create_update_project_cq_submitted_task",
            "delete_multiple": "application.create_delete_project_cq_submitted_task",
        },
        "task_key_dict": {
            "find_single": "project_cq_submitted",
        },
    },
}

producer_data_project_cq_template = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_project_cq_template_task",
            "find_multiple": "application.create_get_project_cq_templates_task",
            "update_single": "application.create_update_project_cq_template_task",
            "delete_multiple": "application.create_delete_project_cq_template_task",
        },
        "task_key_dict": {
            "find_single": "project_cq_template",
            "find_multiple": "project_cq_templates",
        },
    },
}

producer_data_project_register_history = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_project_register_history_task",
            "find_multiple": "rr.create_get_project_register_history_list_task",
            "update_single": "rr.create_update_project_register_history_task",
            "delete_multiple": "rr.create_delete_project_register_history_list_task",
        },
        "task_key_dict": {
            "find_single": "project_register_history",
            "find_multiple": "project_register_history_list",
        },
    },
}

producer_data_project_register_logs = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_multiple": "rr.create_get_project_register_log_list_task",
        },
        "task_key_dict": {
            "find_multiple": "project_register_log_list",
        },
    },
}


producer_data_project_register = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_project_register_task",
            "find_multiple": "rr.create_get_project_registers_task",
            "update_single": "rr.create_update_project_register_task",
            "update_single_list": "rr.create_update_project_register_list_task",
            "delete_multiple": "rr.create_delete_project_registers_task",
        },
        "task_key_dict": {
            "find_single": "project_register",
            "find_multiple": "project_registers",
        },
    },
}

producer_data_project = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_project_task",
            "find_multiple": "application.create_get_projects_task",
            "update_single": "application.create_update_project_task",
            "update_single_list": "application.create_update_project_list_task",
            "delete_multiple": "application.create_delete_projects_task",
        },
        "task_key_dict": {
            "find_single": "project",
            "find_multiple": "projects",
        },
    },
}

producer_data_question_to_model = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_question_to_model_task",
        },
        "task_key_dict": {
            "find_single": "question_to_model",
        },
    },
}

producer_data_register_mapping = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_register_mapping_task",
        },
        "task_key_dict": {
            "find_single": "register_mapping",
        },
    },
}


producer_data_resource_tag = {
    "task_queue": "application_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "application.create_get_resource_tag_task",
            "find_multiple": "application.create_get_resource_tags_task",
            "update_single": "application.create_update_resource_tag_task",
            "delete_multiple": "application.create_delete_resource_tags_task",
        },
        "task_key_dict": {
            "find_single": "resource_tag",
            "find_multiple": "resource_tags",
        },
    },
}


producer_data_tosca_ontology = {
    "task_queue": "rr_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "rr.create_get_tosca_ontology_task",
            "find_multiple": "rr.create_get_tosca_ontology_list_task",
        },
        "task_key_dict": {
            "find_single": "tosca_ontology",
            "find_multiple": "tosca_ontology_list",
        },
    },
}

producer_data_token = {
    "task_queue": "authentication_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "auth.create_get_token_task",
            "find_multiple": "auth.create_get_tokens_task",
            "update_single": "auth.create_update_token_task",
            "update_single_list": "auth.create_update_token_list_task",
            "delete_multiple": "auth.create_delete_tokens_task",
        },
        "task_key_dict": {
            "find_single": "token",
            "find_multiple": "tokens",
        },
    },
}

producer_data_user = {
    "task_queue": "authentication_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_single": "auth.create_get_user_task",
            "find_multiple": "auth.create_get_users_task",
            "update_single": "auth.create_update_user_task",
            "update_single_list": "auth.create_update_user_list_task",
            "delete_multiple": "auth.create_delete_users_task",
        },
        "task_key_dict": {
            "find_single": "user",
            "find_multiple": "users",
        },
    },
}

producer_data_project_diagram_file_terraform = {
    "task_queue": "ad_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_multiple_files": "ad.create_get_terraform_files_task",
            "insert_single_file": "ad.create_insert_terraform_file_task",
            "delete_multiple_files": "ad.create_delete_terraform_files_task",
        },
        "task_key_dict": {
            "find_multiple_files": "terraform_files",
        },
    },
}

producer_data_project_diagram_file_module = {
    "task_queue": "ad_queue",
    "task_mappings": {
        "task_name_dict": {
            "find_multiple_files": "ad.create_get_module_files_task",
            "insert_single_file": "ad.create_insert_module_file_task",
            "delete_multiple_files": "ad.create_delete_module_files_task",
        },
        "task_key_dict": {
            "find_multiple_files": "module_files",
        },
    },
}

__all__ = [
    "producer_data_ad_template",
    "producer_data_attack_enterprise",
    "producer_data_attack_ics",
    "producer_data_attack_mobile",
    "producer_data_authentication",
    "producer_data_generation_rule",
    "producer_data_generation_rules_library",
    "producer_data_group",
    "producer_data_master_cq_template",
    "producer_data_master_cq",
    "producer_data_master_register_logs",
    "producer_data_master_register",
    "producer_data_priority_rules",
    "producer_data_project_ad",
    "producer_data_project_cq_submitted",
    "producer_data_project_cq_template",
    "producer_data_project_cq",
    "producer_data_project_diagram_file_module",
    "producer_data_project_diagram_file_terraform",
    "producer_data_project_register_history",
    "producer_data_project_register_logs",
    "producer_data_project_register",
    "producer_data_project",
    "producer_data_question_to_model",
    "producer_data_register_mapping",
    "producer_data_resource_tag",
    "producer_data_token",
    "producer_data_tosca_ontology",
    "producer_data_user",
]
