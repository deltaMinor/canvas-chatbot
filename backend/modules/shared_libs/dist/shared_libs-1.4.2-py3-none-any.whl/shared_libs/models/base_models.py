from __future__ import annotations

from typing import Any, Dict, List, Mapping, Optional, Sequence, TypeAlias, Union

from pydantic import BaseModel, Field

from ..types.enum import KnowledgeBaseSource

Datetime: TypeAlias = Any
InitialValue: TypeAlias = Any
MetadataModelData: TypeAlias = Any
QuestionnaireValue: TypeAlias = Dict[str, Any]


class UserInfoModel(BaseModel):
    user_id: str
    username: str


class MetadataModel(UserInfoModel):
    timestamp: Datetime


class DatabaseMetadataModel(BaseModel):
    created_on: MetadataModel
    modified_on: MetadataModel


class GroupBaseModel(BaseModel):
    group_id: str
    group_name: str


class JwtDictModel(BaseModel):
    user_id: str
    username: str
    iat: Datetime
    exp: Datetime
    iss: str
    jti: str


class UserEntitlement(BaseModel):
    tag_id: str
    permissions: Optional[List[str]] = []
    permission_type: Optional[str] = ""
    roles: Optional[List[str]] = []


class UserBaseModel(BaseModel):
    email: str
    entitlements: List[UserEntitlement] = []
    is_email_verified: Optional[bool] = False
    is_superuser: Optional[bool] = False
    last_login: Optional[Datetime] = None
    password: str
    user_id: str
    user_status: str = "pending"
    username: str


class ProjectStatusBaseModel(BaseModel):
    conception_questionnaire: Optional[int] = 0
    review_questionnaire: Optional[int] = 0
    architecture_diagram: Optional[int] = 0
    run_assessment: Optional[int] = 0
    resolve_issues: Optional[int] = 0
    view_attack_paths: Optional[int] = 0


class ProjectBaseModel(BaseModel):
    project_id: str
    project_name: str
    project_status: ProjectStatusBaseModel
    resource_tags: Optional[List[str]] = []


class ResourceTagBaseModel(BaseModel):
    tag_id: str
    tag_name: str
    parent_tag_id: str


class QuestionPropertiesItem(BaseModel):
    type: str
    value: str


class UsefulnessPropertiesItem(BaseModel):
    riskIds: List[str]
    value: str


class QuestionProperties(BaseModel):
    examples: List[QuestionPropertiesItem]
    explanations: List[QuestionPropertiesItem]
    helperText: str
    usefulness: List[UsefulnessPropertiesItem]


class QuestionFieldOption(BaseModel):
    label: str
    optionId: str


class QuestionField(BaseModel):
    disabled: bool
    placeholder: str
    required: bool
    type: str
    initialValue: InitialValue
    options: List[QuestionFieldOption]


class QuestionPreConditionProperties(BaseModel):
    extendedField: Optional[QuestionModel] = None
    extendedFieldIdRef: Optional[str] = ""
    fieldIdRef: str
    fieldIdRefList: Optional[List[str]] = []
    optionIds: Optional[List[str]] = []


class QuestionPreCondition(BaseModel):
    description: str
    type: str
    properties: QuestionPreConditionProperties


class QuestionBaseModel(BaseModel):
    fieldId: str
    header: str
    label: str
    field: QuestionField
    preConditions: List[QuestionPreCondition]
    properties: QuestionProperties


class QuestionModel(QuestionBaseModel):
    extendedFields: List[QuestionBaseModel]


class QuestionnaireSummaryModel(BaseModel):
    footer: str


class QuestionnaireSubsectionModel(BaseModel):
    questions: List[QuestionModel]
    subsectionId: str
    subsectionName: str
    summary: QuestionnaireSummaryModel


class QuestionnaireSectionModel(BaseModel):
    questions: List[QuestionModel]
    subsections: List[QuestionnaireSubsectionModel]
    sectionId: str
    sectionName: str
    summary: QuestionnaireSummaryModel


class ConceptionTemplateDictModel(BaseModel):
    templateId: str
    templateName: str
    values: List[Dict[str, Any]]


class ConceptionTemplateBaseModel(BaseModel):
    fieldId: str
    templates: List[ConceptionTemplateDictModel]


class MappingToIM8(BaseModel):
    policyRef: str
    section: str
    stdRef: str


class ExplanationForGenerationRuleBaseModel(BaseModel):
    evidence: Union[str, List[str], None] = Field(union_mode="left_to_right")
    explanation: Optional[list] = []
    result: Optional[str] = ""


class ExplanationForGenerationRule(BaseModel):
    applicability: Optional[Union[str, ExplanationForGenerationRuleBaseModel]] = None
    priority: Optional[Union[str, ExplanationForGenerationRuleBaseModel]] = None


class RecommendedMitigationMeasures(BaseModel):
    header: str
    id: str
    measure: str


class RiskRegisterCore(BaseModel):
    riskScenarioId: str
    category: Optional[str] = ""
    defaultImpact: Optional[int] = 0
    defaultLikelihood: Optional[int] = 0
    defaultRiskLevel: Optional[str] = ""
    keyRisk: Optional[str] = ""
    mappingToATK: Optional[List[str]] = []
    mappingToIM8: Optional[List[MappingToIM8]] = []
    recommendedMitigationMeasures: Optional[List[RecommendedMitigationMeasures]] = []
    riskScenario: Optional[str] = ""
    subcategory: Optional[str] = ""
    explanationForGenerationRule: Optional[ExplanationForGenerationRule] = None


class AttackPathMatchObject(BaseModel):
    step: Optional[str] = ""
    stepName: Optional[str] = ""
    stepRef: Optional[str] = ""
    nodes: Optional[List[str]] = []


class AttackConditionPath(BaseModel):
    condition_edges: List[str]
    condition_nodes: List[str]
    end_node: str
    metapath: List[dict]
    path_id: str
    path_name: str
    path_nodes: dict
    possible_path: List[str]
    start_node: str


class AttackPaths(BaseModel):
    id: str
    applicability: Optional[int] = 0
    attack_action_references: Optional[dict] = None
    label: Optional[str] = ""
    condition_paths: Optional[List[AttackConditionPath]] = []
    match: Optional[List[AttackPathMatchObject]] = []
    name: Optional[str] = ""
    priority: Optional[int] = 0
    rapids_category: Optional[List[str]] = []
    riskScenario: Optional[str] = ""
    keyRisk: Optional[str] = ""
    explanationForGenerationRule: Optional[ExplanationForGenerationRule] = None


class ScenarioLocationParentNodeBaseModel(BaseModel):
    id: str
    source: str


class ScenarioLocationBaseModel(BaseModel):
    boundary: str
    id: str
    name: str
    parentNode: ScenarioLocationParentNodeBaseModel
    tosca_type: str
    type: List[Any]


class ActualMitigationMeasureBaseModel(BaseModel):
    id: str
    completion: bool
    header: str
    measure: str


class AttackSteps(BaseModel):
    name: Optional[str] = ""
    techniqueId: Optional[str] = ""
    techniqueRef: Optional[str] = ""
    location: Optional[str] = ""
    locationId: Optional[str] = ""


class MasterRiskScenario(RiskRegisterCore):
    pass


class ProjectRiskScenario(RiskRegisterCore):
    acceptanceReportedBy: Optional[str] = ""
    acceptanceReportedDate: Optional[str] = ""
    acceptedBy: Optional[str] = ""
    actualMitigationMeasures: Optional[List[ActualMitigationMeasureBaseModel]] = []
    priority: Optional[int] = 0
    applicability: Optional[int] = 0
    knowledgebaseSource: Optional[str] = ""
    location: Optional[List[ScenarioLocationBaseModel]] = []
    remarks: Optional[str] = ""
    residualImpact: Optional[int] = 0
    residualLikelihood: Optional[int] = 0
    residualRiskLevel: Optional[str] = ""
    responseAndRecoverPlan: Optional[str] = ""
    reviewComments: Optional[str] = ""
    sourceRiskScenarioId: Optional[str] = ""
    status: Optional[str] = ""
    tags: Optional[List[str]] = []
    treatmentComments: Optional[str] = ""
    rapidsCategory: Optional[List[str]] = []
    attackSteps: Optional[List[AttackSteps]] = []


class ProjectCacheRiskScenario(BaseModel):
    riskScenarioId: str
    sourceRiskScenarioId: Optional[str] = ""
    knowledgebaseSource: Optional[str] = ""
    cachedFields: Optional[List[CachedFields]] = []


class CachedFields(BaseModel):
    field: Optional[Union[str, int]] = ""
    currentValue: Optional[Union[str, int]] = ""
    newValue: Optional[Union[str, int]] = ""


class RiskRegisterProjectStats(BaseModel):
    riskScenarioId: str
    knowledgebaseSource: Optional[str] = ""
    defaultRiskLevel: Optional[str] = ""
    residualRiskLevel: Optional[str] = ""
    priority: Optional[int] = 0
    applicability: Optional[int] = 0
    rapidsCategory: Optional[List[str]] = []


class ProjectRegisterStatsBaseModel(BaseModel):
    timestamp: Any
    risk_scenarios: Optional[List[RiskRegisterProjectStats]] = []


class RegisterRefBaseModel(BaseModel):
    cq_version_id: str


class RegisterBaseModel(BaseModel):
    schema_: Optional[float] = 0
    category_options: Optional[List[str]] = []
    risk_info: Optional[List[Dict[str, Any]]] = []
    subcategory_options: Optional[Dict[str, List[str]]] = None


class TaskMappingsModel(BaseModel):
    task_name_dict: Dict[str, str]
    task_key_dict: Dict[str, str]


class ProducerDataModel(BaseModel):
    task_queue: str
    task_mappings: Optional[TaskMappingsModel] = None


class CanvasDataViewportBaseModel(BaseModel):
    x: float
    y: float
    zoom: float


class CanvasDataBaseModel(BaseModel):
    nodes: Optional[List[Any]] = []
    edges: Optional[List[Any]] = []
    viewport: CanvasDataViewportBaseModel
    canvas_views: Optional[List[CanvasViewBaseModel]] = []


class CanvasViewIdListBaseModel(BaseModel):
    edge_id_list: List[str]
    node_id_list: List[str]


class ADTemplateBaseModel(BaseModel):
    templateId: str
    templateName: str
    templateData: CanvasDataBaseModel
    templateView: CanvasViewIdListBaseModel


class CanvasBaseModel(BaseModel):
    canvas_data_history: List[CanvasDataBaseModel]
    canvas_data_index: int
    canvas_data: CanvasDataBaseModel
    canvas_id: str


class AttackNodeMappingModel(BaseModel):
    path_id: str
    isin_possible_path: bool
    isin_condition_nodes: bool


class AttackNodeModel(BaseModel):
    node_id: str
    mapping_list: List[AttackNodeMappingModel]


class CanvasViewRefAttackEdgeModel(BaseModel):
    edge_id: str
    condition_edges__path_id_list: List[str]


class CanvasViewRefAttackMappingModel(BaseModel):
    attack_nodes: List[AttackNodeModel]
    attack_edges: List[CanvasViewRefAttackEdgeModel]


class CanvasViewRefModel(BaseModel):
    # attack_mapping: Optional[CanvasViewRefAttackMappingModel] = None
    attack_path_ref: Optional[AttackPaths] = None
    card_ref: Optional[dict] = None


class CanvasViewBaseModel(CanvasViewIdListBaseModel):
    ref: dict
    view_id: str
    view_name: str
    view_only: Optional[bool] = False
    view_type: str


class CanvasCardNodeBaseModel(BaseModel):
    label: str
    node_id: Optional[str] = None
    ref_key: str
    value: str
    card_id_affliations: Optional[List[str]] = []


class RedisTokenBaseModel(BaseModel):
    encoded_token: str
    decoded_token: JwtDictModel
    token_type: str


class BatchInfoModel(BaseModel):
    average_unit_size: int
    batch_count_total: int
    batch_num: Optional[int] = 0
    batch_session_id: str
    batch_size: int
    data_length: int
    data_size: int


class CollectionCommonModel(BaseModel):
    hint: Optional[Any] = None
    comment: Optional[str] = None
    collation: Optional[Any] = None  # pymongo.collation.Collation
    session: Optional[Any] = None  # pymongo.client_session.ClientSession


class CollectionQueryStrictModel(CollectionCommonModel):
    filter: Optional[Dict[str, Any]] = None
    projection: Optional[List[str] | Dict[str, bool]] = None
    skip: Optional[int] = 0
    limit: Optional[int] = 0
    no_cursor_timeout: Optional[bool] = False
    cursor_type: Optional[int] = 0
    sort: Optional[List[Any]] = None
    allow_partial_results: Optional[bool] = False
    batch_size: Optional[int] = 0  # pymongo.cursor.CursorType
    max_time_ms: Optional[int] = None
    max: Optional[Any] = None
    min: Optional[Any] = None
    return_key: Optional[bool] = False
    show_record_id: Optional[bool] = False
    allow_disk_use: Optional[bool] = None


class CollectionQueryModel(CollectionQueryStrictModel):
    batch_info: Optional[BatchInfoModel] = None


class DomainRepositoryQueryModel(CollectionQueryModel):
    raise_if_not_found: Optional[bool] = False
    raise_if_found: Optional[bool] = False


class CollectionUpdateCommonModel(CollectionCommonModel):
    filter: Mapping[str, Any]
    upsert: Optional[bool] = False
    bypass_document_validation: Optional[bool] = False
    array_filters: Optional[Sequence[Mapping[str, Any]]] = None
    let: Optional[Mapping[str, Any]] = None


class CollectionUpdateOneStrictModel(CollectionUpdateCommonModel):
    update: Mapping[str, Any]


class CollectionUpdateSingleModel(CollectionUpdateCommonModel):
    payload: Mapping[str, Any]
    user_info: Mapping[str, Any]
    operator: Optional[str] = "$set"


class DomainRepositoryUpdateOneModel(CollectionUpdateSingleModel):
    pass


class CollectionUpdateParamDictModel(CollectionUpdateCommonModel):
    payload: Mapping[str, Any]


class CollectionUpdateSingleListModel(BaseModel):
    param_dict_list: List[CollectionUpdateParamDictModel]
    user_info: Mapping[str, Any]


class CollectionDeleteManyStrictModel(CollectionCommonModel):
    filter: Mapping[str, Any]
    let: Optional[Mapping[str, Any]] = None


class CollectionDeleteMultipleModel(CollectionDeleteManyStrictModel):
    pass


class ParamDictModel(BaseModel):
    filter: Mapping[str, str]
    payload: Mapping[str, Any]


class RegisterStatsDataModel(BaseModel):
    timestamp: Optional[List[str]] = []
    low: Optional[List[int]] = []
    medium: Optional[List[int]] = []
    medium_high: Optional[List[int]] = []
    high: Optional[List[int]] = []
    very_high: Optional[List[int]] = []
    unspecified: Optional[List[int]] = []
    sum: Optional[List[int]] = []


class RegisterRapidsStatsDataModel(BaseModel):
    timestamp: Optional[List[str]] = []
    ransomware: Optional[List[int]] = []
    applicationSystemVulnerability: Optional[List[int]] = []
    phishing: Optional[List[int]] = []
    insiderThreat: Optional[List[int]] = []
    ddos: Optional[List[int]] = []
    supplyChainCompromise: Optional[List[int]] = []
    sum: Optional[List[int]] = []


class RegisterStatsComputeModel(BaseModel):
    low: Optional[int] = 0
    medium: Optional[int] = 0
    medium_high: Optional[int] = 0
    high: Optional[int] = 0
    very_high: Optional[int] = 0
    unspecified: Optional[int] = 0


class RegisterRapidsStatsComputeModel(BaseModel):
    ransomware: Optional[int] = 0
    applicationSystemVulnerability: Optional[int] = 0
    phishing: Optional[int] = 0
    insiderThreat: Optional[int] = 0
    ddos: Optional[int] = 0
    supplyChainCompromise: Optional[int] = 0


class DatabaseModel(BaseModel):
    _id: Optional[str] = ""
    metadata: Optional[DatabaseMetadataModel] = None

    def __init__(self, **data):
        super().__init__(**data)
        if "_id" in data:
            self._id = f'{data.get("_id")}'

    def model_dump(self, dump_id=False, **kwargs) -> Dict[str, Any]:
        dump_val = super().model_dump(**kwargs)
        if dump_id:
            dump_val["_id"] = str(self._id)
            return dump_val
        if "_id" in dump_val:
            del dump_val["_id"]
        return dump_val


class UpdateDescriptionBaseModel(BaseModel):
    removedFields: List[Any]
    truncatedArrays: List[Any]
    updatedFieldKeys: Optional[List[str]] = []
    updatedFields: Optional[Dict[str, Any]] = None

    def __init__(self, **data):
        super().__init__(**data)
        if not data:
            return

        updatedFields = data.get("updatedFields")
        if isinstance(updatedFields, dict):
            self.updatedFieldKeys = list(updatedFields.keys())
            self.updatedFields = None


class RegisterLogsBaseModel(BaseModel):
    documentKey: Dict[str, Any]
    fullDocument: Optional[Dict[str, Any]] = None
    fullDocumentKeys: Optional[List[str]] = []
    ns: Dict[str, Any]
    operationType: str
    updateDescription: Optional[UpdateDescriptionBaseModel] = None
    wallTime: Datetime

    def __init__(self, **data):
        super().__init__(**data)
        if not data:
            return

        if "documentKey" in data and "_id" in (data.get("documentKey") or {}):
            documentKey_id = data.get("documentKey").get("_id")
            self.documentKey["_id"] = str(documentKey_id)
            self.documentKey["id"] = str(documentKey_id)

        fullDocument = data.get("fullDocument")
        if isinstance(fullDocument, dict):
            self.fullDocumentKeys = list(fullDocument.keys())
            self.fullDocument = None


class AttackDocsModel(BaseModel):
    attack_ics_docs: Optional[List[dict]] = []
    attack_mobile_docs: Optional[List[dict]] = []
    attack_enterprise_docs: Optional[List[dict]] = []
    attack_docs: Optional[List[dict]] = []


class FeedbackFormModel(BaseModel):
    feedback_type: str
    feedback_content: str
    user_id: str
    feedback_id: str
