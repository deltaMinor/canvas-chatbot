from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class KbAttackIcsService(DomainRepositoryService):
    """
    Service class for AttackIcs operations. Inherits from DomainRepositoryService.

    Attributes:
        repository (Repository): The repository object that this service will use to perform operations.
    """

    def __init__(self, repository: Repository):
        """
        Initialize the KbAttackIcsService with a given repository.

        Args:
            repository (Repository): The repository object to perform operations with.
        """
        super().__init__(repository=repository)
        self.repository = repository
