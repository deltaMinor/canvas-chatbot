from ....domain.shared.file_repository import DomainFileRepositoryService
from ....infrastructure.file_repository.service import FileRepository


class ProjectADFileModuleService(DomainFileRepositoryService):
    """
    Handles operations related to Project Diagram File Modules.

    This service is responsible for managing the interactions between the
    application and the file repository for Project Diagram File Modules.

    Attributes:
        repository (FileRepository): The repository that this service interacts with.
    """

    def __init__(self, repository: FileRepository):
        """
        Constructs all the necessary attributes for the ProjectADFileModuleService object.

        Args:
            repository (FileRepository): The repository that this service will manage.
        """
        super().__init__(repository=repository)
        self.repository = repository
