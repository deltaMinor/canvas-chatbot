from ... import lib_config
from .database_client_manager import DatabaseClientManager

DB_URL = lib_config.DB_URL
DB_NAME = lib_config.DB_NAME

database_client_manager = DatabaseClientManager(
    DB_URL=DB_URL,
    DB_NAME=DB_NAME,
)

# tm_collection_names = database_client_manager.collection_names
# tm_db_server_client = database_client_manager.server_client
tm_db_client = database_client_manager.database_client
tm_repository_watcher_classes = database_client_manager.repository_watcher_classes
