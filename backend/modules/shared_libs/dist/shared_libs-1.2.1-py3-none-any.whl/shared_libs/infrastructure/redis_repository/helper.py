import redis


class RedisRepositoryHelper:
    """
    A helper service class for handling operations related to a Redis repository.

    This class provides a base for classes that need to interact with a Redis repository. It holds a reference to a Redis client that can be used to perform operations on the Redis repository.

    Attributes:
        redis_client (redis.Redis): The Redis client used to interact with the Redis repository.

    Note:
        This class currently does not have any methods.
        Methods should be added as needed in the future.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
    ):
        """
        Constructs all the necessary attributes for the RedisRepositoryHelper object.

        Args:
            redis_client (redis.Redis): The Redis client that this service will use to interact with the Redis repository.
        """
        self.redis_client = redis_client
