import json
from typing import List

import redis

from ... import lib_config
from ...decorators.exception import raise_exception
from ...decorators.validation import verify_params
from .helper import RedisRepositoryHelper


class RedisRepository(RedisRepositoryHelper):
    """
    A class for handling operations related to a Redis repository.

    This class provides methods to get keys and retrieve matched objects in Redis. It uses a Redis client to interact with the Redis repository and has a default expiry time for keys.

    Attributes:
        redis_client (redis.Redis): The Redis client used to interact with the Redis repository.
        default_expiry (int): The default expiry time for keys in the Redis repository, in seconds.
    """

    def __init__(
        self,
        redis_client: redis.Redis,
        default_expiry: int = lib_config.REDIS_DEFAULT_EXPIRY,
    ):
        """
        Constructs all the necessary attributes for the RedisRepository object.

        Args:
            redis_client (redis.Redis): The Redis client that this repository will use to interact with the Redis repository.
            default_expiry (int, optional): The default expiry time for keys in the Redis repository, in seconds. Defaults to lib_config.REDIS_DEFAULT_EXPIRY.
        """
        self.redis_client = redis_client
        self.default_expiry = default_expiry

    @raise_exception("Failed to get redis keys.")
    def get_keys(self, pattern="*"):
        """
        Gets keys from the Redis repository.

        Args:
            pattern (str, optional): The pattern to match keys. Defaults to "*".

        Returns:
            list: The keys from the Redis repository.
        """
        return self.redis_client.keys(
            pattern=pattern,
        )

    @raise_exception("Failed to retrieve matched objects in redis.")
    @verify_params(key_list=["name"])
    def get_object_dict_in_redis(self, name: str) -> dict | None:
        """
        Retrieves a matched object in the Redis repository.

        Args:
            name (str): The name of the object.

        Returns:
            dict | None: The matched object, or None if no object was found.
        """
        res = self.redis_client.hgetall(
            name=name,
        )
        if not res or not len(res.keys()):
            return None
        res = {k.decode(): v.decode() for k, v in res.items()}
        res["item"] = json.loads(res.get("json_string", {}))
        return res

    @raise_exception("Failed to retrieve matched items.")
    @verify_params(key_list=["name"])
    def get_item_in_redis(self, name: str) -> dict | None:
        """
        Retrieves items from Redis based on the provided name.

        This function uses the Redis client to fetch all items associated with the given name.
        It then decodes the JSON string and returns the items as a dictionary.

        Args:
            name (str): The name of the items to retrieve from Redis.

        Returns:
            dict | None: A dictionary of items retrieved from Redis. If no items are found, None is returned.

        Raises:
            Exception: If there is a failure in retrieving the items from Redis or if the decoding of the JSON string fails.
        """
        res = self.get_object_dict_in_redis(name=name)
        if not res:
            return None
        return res.get("item")

    @raise_exception("Failed to set value for key in Redis.")
    @verify_params(key_list=["name", "mapping"])
    def set_item_in_redis(
        self,
        name: str,
        mapping: dict | list | None = None,
        expiry: int = 60,
        **kwargs,
    ) -> bool | None:
        """
        Sets an item in Redis with a specified expiry time.

        This function uses the Redis client to set a value for a given key (name) with a specified expiry time.
        The value to be set is a dictionary (mapping) which is converted to a JSON string before being stored in Redis.

        Args:
            name (str): The key for which the value is to be set in Redis.
            mapping (Dict[str, Any]): The value to be set in Redis. Must be a dictionary.
            expiry (int, optional): The expiry time for the key in seconds. Defaults to 60.
            **kwargs: Additional keyword arguments to be passed to the Redis client's hset method.

        Returns:
            bool | None: Returns True if the operation was successful, False if not. Returns None if an exception is raised.

        Raises:
            TypeError: If the value to be set in Redis is not a dictionary.
            Exception: If there is a failure in setting the value in Redis.
        """
        expiry = expiry or self.default_expiry
        if not isinstance(mapping, dict | list):
            raise TypeError("Redis value is not a dict or list.")

        # Set the value in Redis
        self.redis_client.hset(
            name=name,
            mapping={"json_string": json.dumps(mapping, default=str)},
        )
        self.redis_client.expire(
            name=name,
            time=expiry,
        )

        # Set additional fields in Redis. String values only.
        for item in kwargs.get("mapping_list", []):
            self.redis_client.hset(
                name=name,
                mapping=item,
            )

    @raise_exception("Failed to delete items in Redis")
    @verify_params(key_list=["names"])
    def delete_item_in_redis(self, names: List[str]) -> None:
        """
        Deletes the specified items in Redis.

        Args:
            names (List[str]): A list of keys representing the items to be deleted from Redis.

        Raises:
            Exception: If there is a failure in deleting any of the items from Redis.
        """
        for name in names:
            self.redis_client.delete(name)

    @raise_exception("Failed to set expiration for key in Redis")
    @verify_params(key_list=["redis_query_key"])
    def expire_item_in_redis(
        self,
        redis_query_key: str,
        expiry: int | None = None,
    ) -> bool:
        """
        Sets an expiration time for a specific key in Redis.

        This method sets an expiration time for the provided key in Redis. If an expiry time is
        provided, the key will expire after that many seconds. If no expiry time is provided,
        the default expiry time is used.

        Args:
            redis_query_key (str): The key for which to set the expiration time.
            expiry (int, optional): The number of seconds after which the key should expire.
                If not provided, the default expiry time is used.

        Returns:
            bool: True if the operation was successful, False otherwise.
        """
        expiry = expiry or self.default_expiry
        return self.redis_client.expire(redis_query_key, time=expiry)
