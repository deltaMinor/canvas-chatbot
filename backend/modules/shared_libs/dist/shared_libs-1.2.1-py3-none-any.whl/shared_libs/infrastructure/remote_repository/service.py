import json
from typing import Any, Callable

from ... import lib_config
from ...decorators.exception import raise_exception
from ...decorators.validation import verify_params
from ...infrastructure.producer.service import Producer
from ...infrastructure.redis_repository.service import RedisRepository
from ...logger.app_logger import logger
from ...models.base_models import (
    CollectionDeleteMultipleModel,
    CollectionQueryModel,
    CollectionUpdateSingleListModel,
    CollectionUpdateSingleModel,
)
from .helper import RemoteRepositoryHelper


class RemoteRepository(RemoteRepositoryHelper):
    """
    Handles remote database operations.

    This class provides methods for performing operations on a remote database, such as finding, updating, and deleting records.
    It uses a producer to send tasks to a task queue, and a Redis repository for caching.

    Attributes:
        producer (Producer): The producer used to send tasks to the task queue.
        redis_repository (RedisRepository): The Redis repository used for caching.
    """

    def __init__(
        self,
        producer: Producer,
        redis_repository: RedisRepository = None,
    ):
        """
        Initializes a new instance of the RemoteRepository class.

        Args:
            producer (Producer): The producer used to send tasks to the task queue.
            redis_repository (RedisRepository, optional): The Redis repository used for caching. Defaults to None.
        """
        super().__init__(producer=producer)
        self.producer = producer
        self.redis_repository = redis_repository

    @raise_exception("An error occurred while retrieving or setting the value in Redis.")
    def get_value(
        self,
        task_type: str,
        task_body: dict,
        func: Callable,
    ) -> Any:
        """
        Retrieves the value from Redis if it exists, otherwise sets it.

        This function checks if the value exists in Redis. If it does, it returns the value. If it doesn't, it uses the
        provided function to retrieve the value, stores the value in Redis, and then returns the value.

        Args:
            task_type (str): The type of the task to be sent to the producer.
            task_body (dict): The body of the task.
            func (Callable): The function to retrieve the value if it doesn't exist in Redis.

        Returns:
            Any: The value retrieved from Redis or the remote database, or None if no value was found.

        Raises:
            Exception: If there is a failure in retrieving or setting the value in Redis.
        """
        task_name, _ = self.producer.get_task_attributes_from_mappings(task_type)
        name = f"{task_name}_{json.dumps(task_body)}"

        # Check if the item exists in Redis
        item = self.redis_repository.get_item_in_redis(
            name=name,
        )
        if item:
            logger.info("Returning cached value in remote repository ...")
            return item

        # Get the value from the remote database
        task_value = func(
            task_type=task_type,
            task_body=task_body,
        )
        if task_value:
            self.redis_repository.set_item_in_redis(
                name=name,
                mapping=task_value,
                expiry=lib_config.REDIS_DOC_EXPIRY,
            )
        return task_value

    @raise_exception("An error occurred while finding a single record in remote database.")
    def find_single(
        self,
        task_type="find_single",
        **kwargs,
    ) -> Any:
        """
        Finds a single record in the remote database.

        This method sends a task to a producer to find a single record in the remote database that matches the criteria
        specified in the kwargs. The kwargs should include a 'filter' parameter which is a dictionary specifying the
        search criteria. If a matching record is found in the Redis cache, it is returned. Otherwise, the method retrieves
        the record from the remote database, stores it in the Redis cache, and then returns it.

        Args:
            task_type (str, optional): The type of the task to be sent to the producer. Defaults to "find_single".
            **kwargs: Additional parameters. Must include a 'filter' parameter which is a dictionary specifying the search criteria.

        Returns:
            Any: The record retrieved from the remote database or Redis cache, or None if no record was found.

        Raises:
            Exception: If there is a failure in finding the record in the remote database.
        """
        task_body = {
            **CollectionQueryModel(**kwargs).model_dump(),
        }
        if not self.redis_repository:
            return self.producer.get_task_value(
                task_type=task_type,
                task_body=task_body,
            )

        return self.get_value(
            task_type=task_type,
            task_body=task_body,
            func=self.producer.get_task_value,
        )

    @raise_exception("An error occurred while finding multiple records in remote database.")
    def find_multiple(
        self,
        task_type="find_multiple",
        **kwargs,
    ) -> Any:
        """Finds multiple records in the remote database.

        This method sends a task to the Celery task queue to perform the find operation and retrieves the results.
        The criteria for the find operation are specified in the kwargs.

        Args:
            task_type (str, optional): The type of the task to be sent to the Celery task queue. Defaults to "find_multiple".
            **kwargs (Any): The criteria for the find operation.

        Returns:
            Any: The list of records that were found, or None if no records were found.

        Raises:
            Exception: If an error occurs while finding the records. The exception message includes the reason for the error.
        """
        task_body = {
            **CollectionQueryModel(**kwargs).model_dump(),
        }
        if not self.redis_repository:
            return self.producer.get_task_values(
                task_type=task_type,
                task_body=task_body,
            )

        return self.get_value(
            task_type=task_type,
            task_body=task_body,
            func=self.producer.get_task_values,
        )

    @raise_exception("An error occurred while updating a single record in remote database.")
    @verify_params(key_list=["payload", "user_info"])
    def update_single(
        self,
        payload,
        user_info,
        **kwargs,
    ) -> Any:
        """Updates a single record in the remote database.

        This method sends a task to the Celery task queue to perform the update operation and retrieves the result.
        The new data for the record is provided in the 'payload'. Additional parameters for the update operation can be specified in the kwargs.

        Args:
            payload (Dict[str, Any]): The new data for the record.
            user_info (Dict[str, Any]): The user information.
            **kwargs (Any): Additional parameters for the update operation.

        Returns:
            Any: The result of the update operation, which includes the updated record or an error message.

        Raises:
            Exception: If an error occurs while updating the record. The exception message includes the reason for the error.
        """
        task_body = {
            **CollectionUpdateSingleModel(
                **kwargs,
                payload=payload,
                user_info=user_info,
            ).model_dump(),
        }
        return self.producer.get_task_value(
            task_type="update_single",
            task_body=task_body,
        )

    @raise_exception(
        "An error occurred while updating a list of single records in remote database."
    )
    @verify_params(key_list=["param_dict_list", "user_info"])
    def update_single_list(
        self,
        param_dict_list,
        user_info,
    ) -> Any:
        """
        Updates a list of single records in the remote database.

        This method sends a task to a producer to update a list of single records in the remote database.
        Each item in the 'param_dict_list' should be a dictionary containing the query parameters and the new data for the update.

        Args:
            param_dict_list (list): A list of dictionaries, each containing the query parameters and the new data for the update.
            user_info (dict): The user information, used to verify the user's access rights.

        Returns:
            Any: The result of the task sent to the producer. This object includes information about the status and result of the task.

        Raises:
            Exception: If an error occurs while trying to update the records.
        """
        task_body = {
            **CollectionUpdateSingleListModel(
                param_dict_list=param_dict_list,
                user_info=user_info,
            ).model_dump(),
        }
        return self.producer.get_task_value(
            task_type="update_single_list",
            task_body=task_body,
        )

    @raise_exception("An error occurred while deleting multiple records in remote database.")
    def delete_multiple(self, **kwargs) -> Any:
        """Deletes multiple records in the remote database.

        This method sends a task to the Celery task queue to perform the delete operation.
        The criteria for the delete operation are specified in the kwargs.

        Args:
            **kwargs (Any): The criteria for the delete operation.

        Returns:
            Any: The result of the delete operation.

        Raises:
            Exception: If an error occurs while deleting the records. The exception message includes the reason for the error.
        """
        task_body = {
            **CollectionDeleteMultipleModel(**kwargs).model_dump(),
        }
        return self.producer.get_task_value(
            task_type="delete_multiple",
            task_body=task_body,
        )
