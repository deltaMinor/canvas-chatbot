from typing import Any, List

from pymongo.results import DeleteResult, UpdateResult

from ...decorators.exception import raise_exception
from ...decorators.validation import verify_params
from ...models.base_models import (
    CollectionDeleteManyStrictModel,
    CollectionQueryStrictModel,
    CollectionUpdateOneStrictModel,
    CollectionUpdateSingleModel,
)
from ..database_client.repository_collection import RepositoryCollection
from .helper import RepositoryHelper


class Repository(RepositoryHelper):
    """
    A class used to interact with the database.

    This class provides methods to find, update and delete records in the database.

    Attributes:
        collection (RepositoryCollection | Collection): The collection to interact with.

    """

    collection = None

    def __init__(self, collection: RepositoryCollection):
        """
        Constructs a new Repository instance.

        Args:
            collection (RepositoryCollection): The collection to interact with.
        """
        super().__init__()
        self.collection = collection

    @raise_exception("An error occurred while finding a single record in database.")
    def find_single(self, **kwargs) -> Any | None:
        """
        Finds a single record in the database.

        Args:
            **kwargs: The query parameters.

        Returns:
            Any | None: The found record or None if no record was found.
        """
        return self.collection.find_one(
            **CollectionQueryStrictModel(**kwargs).model_dump(),
        )

    @raise_exception("An error occurred while finding multiple records in database.")
    def find_multiple(self, **kwargs) -> List[Any]:
        """
        Finds multiple records in the database.

        Args:
            **kwargs: The query parameters.

        Returns:
            List[Any]: The found records.
        """
        cursor = self.collection.find(
            **CollectionQueryStrictModel(**kwargs).model_dump(),
        )
        return list(cursor)

    @raise_exception("An error occurred while updating a single record in database.")
    @verify_params(key_list=["payload", "user_info"])
    def update_single(
        self,
        payload: dict,
        user_info: dict,
        **kwargs,
    ) -> UpdateResult:
        """
        Updates a single record in the database.

        This method retrieves the operator from kwargs, defaulting to "$set" if not provided.
        It then prepares the payload for update by removing the "id" key and generates a
        metadata model using the payload and user_info. If the operator is not "$set", it
        updates the found record in the database with the prepared payload and the metadata
        model using the operator. If the operator is "$set", it updates the found record in
        the database with the prepared payload and the metadata model using the operator.
        In both cases, it returns the result of the update operation.

        Args:
            payload (dict): The data to update the record with.
            user_info (dict): The user information to add to the metadata.
            **kwargs: Arbitrary keyword arguments used to find the record to update and
                    optionally specify the operator for the update operation.

        Returns:
            UpdateResult: The result of the update operation.

        Raises:
            NotFound: If no record matching the provided kwargs is found in the database.
        """
        operator = kwargs.get("operator", "$set")
        _payload = {k: v for k, v in payload.items() if k not in ["id"]}
        metadata_model = self.get_metadata_model(
            payload=payload,
            user_info=user_info,
        )

        if operator != "$set":
            return self.collection.update_one(
                **CollectionUpdateOneStrictModel(
                    **kwargs,
                    update={
                        operator: _payload,
                        "$set": {"metadata": metadata_model.model_dump()},
                    },
                ).model_dump(),
            )

        return self.collection.update_one(
            **CollectionUpdateOneStrictModel(
                **kwargs,
                update={
                    operator: {
                        **_payload,
                        "metadata": metadata_model.model_dump(),
                    }
                },
            ).model_dump(),
        )

    @raise_exception("An error occurred while updating a list of single records in database.")
    @verify_params(key_list=["param_dict_list", "user_info"])
    def update_single_list(
        self,
        param_dict_list,
        user_info,
    ) -> List[UpdateResult]:
        """
        Updates a list of single records in the database.

        This method will update a list of single records in the database based on the provided list of parameters.
        Each item in the 'param_dict_list' should be a dictionary containing the query parameters and the new data for the update.

        Args:
            param_dict_list (list): A list of dictionaries, each containing the query parameters and the new data for the update.
            user_info (dict): The user information.

        Returns:
            List[UpdateResult]: A list of UpdateResult objects, each representing the result of an update operation.
        """
        out = []
        for param_dict in param_dict_list:
            res = self.update_single(
                **CollectionUpdateSingleModel(
                    **param_dict,
                    user_info=user_info,
                ).model_dump(),
            )
            out.append(res)
        return out

    @raise_exception("An error occurred while deleting multiple records in database.")
    def delete_multiple(self, **kwargs) -> DeleteResult:
        """
        Deletes multiple records from the database.

        This method deletes multiple records from the database that match the criteria specified in the kwargs.
        The kwargs should include a 'filter' parameter which is a dictionary specifying the deletion criteria.

        Args:
            **kwargs: Additional parameters. Must include a 'filter' parameter which is a dictionary specifying the deletion criteria.

        Returns:
            DeleteResult: The result of the delete operation, which includes the number of records deleted.
        """
        return self.collection.delete_many(
            **CollectionDeleteManyStrictModel(**kwargs).model_dump(),
        )
