from functools import cached_property
from typing import List

from pymongo import MongoClient
from pymongo.database import Database

from ...decorators.exception import raise_exception
from ...logger.app_logger import logger
from .repository_watcher import RepositoryWatcher


class DatabaseClientManager:
    def __init__(
        self,
        DB_URL: str,
        DB_NAME: str,
    ):
        self.DB_URL = DB_URL
        self.DB_NAME = DB_NAME

    @cached_property
    def server_client(self) -> MongoClient:
        return self.get_server_client()

    @cached_property
    def database_client(self) -> Database:
        return self.get_database_client()

    @cached_property
    def collection_names(self) -> List[str]:
        return self.get_collection_names()

    @property
    def repository_watcher_classes(self) -> List[RepositoryWatcher]:
        return self.get_repository_watcher_classes()

    @raise_exception("Failed to retrieve server client.")
    def get_server_client(self) -> MongoClient:
        logger.info(f"Attempting database server connection ...")
        logger.info(f"Database url : {self.DB_URL}")

        # Create a MongoClient instance with the provided URL, enabling fsync to force writes to the disk.
        # Also, set a server selection timeout of 2000 milliseconds.
        mongoClient = MongoClient(self.DB_URL, fsync=True, serverSelectionTimeoutMS=2000)
        if not mongoClient:
            raise Exception("Failed to initialize mongoClient.")
        mongoClient.admin.command("ismaster")
        logger.info(f"Database server connection is alive.")

        # Get a list of all database names from the MongoDB server.
        db_list = mongoClient.list_database_names()
        logger.info(f"Databases : {db_list}")

        return mongoClient

    @raise_exception("Failed to retrieve database client.")
    def get_database_client(self) -> Database:
        logger.info(f"Attempting database connection ...")
        logger.info(f"Database name : {self.DB_NAME}")

        # Get a client for the specified database
        database_client = self.server_client[self.DB_NAME]
        logger.info(f"Database connection is alive.")

        return database_client

    @raise_exception("Failed to retrieve collection names.")
    def get_collection_names(self):
        # Get a list of all collection names in the database
        all_collection_names = self.database_client.list_collection_names()
        collection_names = [n for n in all_collection_names if "_log" not in n]
        logger.info(f"Collections: {collection_names}")
        return collection_names

    @raise_exception("Failed to retrieve repository watcher classes.")
    def get_repository_watcher_classes(self) -> List[RepositoryWatcher]:
        repository_watcher_classes = []
        for collection_name in self.collection_names:
            repository_watcher_classes.append(
                RepositoryWatcher(
                    db_client=self.database_client,
                    collection_name=collection_name,
                )
            )
        return repository_watcher_classes
