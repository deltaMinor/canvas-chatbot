from functools import wraps
from typing import Callable

from rest_framework.request import Request

from ..logger.app_logger import logger
from ..producers.authentication_producer import AuthenticationProducer
from .exception import raise_exception

def authenticated_only_func(auth_producer: AuthenticationProducer) -> Callable:

    def decorator_function(func: Callable) -> Callable:

        @wraps(func)
        def wrapper(self, request: Request, *args, **kwargs):
            """
            The decorator for the view function.

            Args:
                self: The instance of the class where the decorated function is defined.
                request (HttpRequest): The request instance.
                *args: Variable length argument list.
                **kwargs: Arbitrary keyword arguments.

            Returns:
                Callable: The result of the view function.
            """
            auth_producer.verify_login_token(request)
            return func(self, request, auth_producer, *args, **kwargs)

        return wrapper

    return decorator_function


__all__ = [
    "authenticated_only_func",
]
