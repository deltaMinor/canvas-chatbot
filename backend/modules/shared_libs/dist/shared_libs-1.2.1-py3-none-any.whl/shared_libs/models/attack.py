from typing import Any, List, Optional

from pydantic import BaseModel


class ExternalReference(BaseModel):
    description: Optional[str] = ""
    externalId: Optional[str] = ""
    sourceName: str
    url: Optional[str] = ""


class KillChainPhase(BaseModel):
    killChainName: str
    phaseName: str


class AttackPatternXMitreContent(BaseModel):
    objectModified: str
    objectRef: str


class AttackPatternDefinition(BaseModel):
    statement: str


class AttackPatternCoreModel(BaseModel):
    bundleId: str
    created: str
    id: str
    specVersion: str
    type: str


class AttackPatternAddOnModel(BaseModel):
    tactics: Optional[List[str]] = []


class AttackPattern(AttackPatternCoreModel, AttackPatternAddOnModel):
    aliases: Optional[List[str]] = []
    createdByRef: Optional[str] = ""
    definition: Optional[AttackPatternDefinition] = None
    definitionType: Optional[str] = ""
    description: Optional[str] = ""
    externalReferences: Optional[List[ExternalReference]] = []
    firstSeen: Optional[str] = ""
    identityClass: Optional[str] = ""
    isFamily: Optional[bool | None] = None
    killChainPhases: Optional[List[KillChainPhase]] = []
    lastSeen: Optional[str] = ""
    modified: Optional[str] = ""
    name: Optional[str] = ""
    objectMarkingRefs: Optional[List[str]] = []
    relationshipType: Optional[str] = ""
    revoked: Optional[bool | None] = None
    sourceRef: Optional[str] = ""
    tacticRefs: Optional[List[str]] = []
    targetRef: Optional[str] = ""
    xMitreAliases: Optional[List[str]] = []
    xMitreAttackSpecVersion: Optional[str] = ""
    xMitreCollectionLayers: Optional[List[str]] = []
    xMitreContents: Optional[List[AttackPatternXMitreContent]] = []
    xMitreContributors: Optional[List[str]] = []
    xMitreDataSourceRef: Optional[str] = ""
    xMitreDeprecated: Optional[bool | None] = None
    xMitreDetection: Optional[str] = ""
    xMitreDomains: Optional[List[str]] = []
    xMitreFirstSeenCitation: Optional[str] = ""
    xMitreIsSubtechnique: Optional[bool | None] = None
    xMitreLastSeenCitation: Optional[str] = ""
    xMitreModifiedByRef: Optional[str] = ""
    xMitreOldAttackId: Optional[str] = ""
    xMitrePlatforms: Optional[List[str]] = []
    xMitreShortname: Optional[str] = ""
    xMitreTacticType: Optional[List[str]] = []
    xMitreVersion: Optional[str] = ""


class AttackDocsModel(BaseModel):
    attack_ics_docs: List[AttackPattern]
    attack_mobile_docs: List[AttackPattern]
    attack_enterprise_docs: List[AttackPattern]
    attack_docs: List[AttackPattern]
