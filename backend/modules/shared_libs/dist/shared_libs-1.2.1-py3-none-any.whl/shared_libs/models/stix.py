# STIX 2.1
from typing import List, Optional, Union

from pydantic import BaseModel, Field
from typing_extensions import Annotated, Literal

from ..types.enum import (
    StixExtensionType,
    StixObjectType,
    StixOperatorType,
    StixScopeType,
)

"""
STIX 2.1 Glossary

AV - Anti-Virus / Anti-Malware solution
CAPEC - Common Attack Pattern Enumeration and Classification
Consumer - Any entity that receives STIX content
CTI - Cyber Threat Intelligence
Deprecated - STIX features or properties that are in the process of being 
replaced by newer ones.
Embedded Relationship - A link (an "edge" in a graph) between one STIX Object 
and another represented as a property on one object containing the ID of 
another object
Entity - Anything that has a separately identifiable existence (e.g., 
organization, person, group, etc.)
IEP - FIRST (Forum of Incident Response and Security Teams) Information 
Exchange Policy
Instance - A single occurrence of a STIX Object version
MTI - Mandatory To Implement
Object Creator - The entity that created or updated a STIX Object (see section 
3.5)
Object Representation - An instance of an object version that is serialized as 
STIX
Producer - Any entity that distributes STIX content, including object creators 
as well as those passing along existing content
SCO - STIX Cyber-observable Object
SDO - STIX Domain Object (a "node" in a graph)
SMO - STIX Meta Object
SRO - STIX Relationship Object (one mechanism to represent an "edge" in a 
graph)
STIX - Structured Threat Information Expression
STIX Content - STIX documents, including STIX Objects, STIX Objects grouped as 
bundles, etc.
STIX Object - A STIX Domain Object (SDO), STIX Cyber Observable Object (SCO), 
STIX Relationship Object (SRO), or STIX Meta Object (SMO).
STIX Relationship - A link (an "edge" in a graph) between two STIX Objects 
represented by either an SRO or an embedded relationship
STIX Extension - A set of mechanisms supporting adding new objects and updating 
existing objects in a standard way.
TAXII - An application layer protocol for the communication of cyber threat 
information
TLP - Traffic Light Protocol
TTP - Tactic, technique, or procedure; behaviors and resources that attackers 
use to carry out their attacks
"""

OpenVocab = Annotated[str, Field(...)]
Lang = Annotated[str, Field(...)]
Identifier = Annotated[str, Field(...)]
GroupIdentifier = Annotated[str, Field(..., pattern="^grouping--")]
IdentityIdentifier = Annotated[str, Field(..., pattern="^identity--")]
ProcessIdentifier = Annotated[str, Field(..., pattern="^process--")]
MarkingDefinitionIdentifier = Annotated[
    str,
    Field(..., pattern="^marking-definition--"),
]
ExtensionDefinitionIdentifier = Annotated[
    str,
    Field(..., pattern="^extension-definition--"),
]
BundleIdentifier = Annotated[str, Field(..., pattern="^bundle--")]
StartRefIdentifier = Annotated[
    str,
    Field(..., pattern="^(attack-action|attack-condition)--"),
]
EffectRefIdentifier = Annotated[
    str,
    Field(..., pattern="^(attack-action|attack-operator|attack-condition)--"),
]
ObjectRefIdentifier = Annotated[
    str,
    Field(..., pattern="^[a-z-]+--"),
]

AttackActionIdentifier = Annotated[str, Field(..., pattern="^attack-action--")]
AttackAssetIdentifier = Annotated[str, Field(..., pattern="^attack-asset--")]
AttackConditionIdentifier = Annotated[str, Field(..., pattern="^attack-condition--")]
AttackFlowIdentifier = Annotated[str, Field(..., pattern="^attack-flow--")]
AttackOperatorIdentifier = Annotated[str, Field(..., pattern="^attack-operator--")]
AttackPatternIdentifier = Annotated[str, Field(..., pattern="^attack-pattern--")]


class StixExternalReference(BaseModel):
    source_name: str
    description: Optional[str] = ""
    url: Optional[str] = ""
    hashes: Optional[str] = ""
    external_id: Optional[str] = ""


class StixGranularMarkingModel(BaseModel):
    selectors: List[str]
    lang: Optional[Lang] = ""
    marking_ref: Optional[MarkingDefinitionIdentifier] = None


class StixSDOModel(BaseModel):
    # Required Fields
    type: str
    spec_version: str
    id: str
    created: str
    modified: str
    # Optional Fields
    created_by_ref: Optional[IdentityIdentifier] = None
    revoked: Optional[bool] = False
    labels: Optional[List[str]] = []
    confidence: Optional[int] = None
    lang: Optional[Lang] = ""
    external_references: Optional[List[StixExternalReference]] = []
    object_marking_refs: Optional[List[str]] = []
    granular_markings: Optional[List[StixGranularMarkingModel]] = []
    extensions: Optional[dict] = None


class StixSROModel(BaseModel):
    # Required Fields
    type: str
    spec_version: str
    id: str
    created: str
    modified: str
    # Optional Fields
    created_by_ref: Optional[IdentityIdentifier] = None
    revoked: Optional[bool] = False
    labels: Optional[List[str]] = []
    confidence: Optional[int] = None
    lang: Optional[Lang] = ""
    external_references: Optional[List[StixExternalReference]] = []
    object_marking_refs: Optional[List[str]] = []
    granular_markings: Optional[List[StixGranularMarkingModel]] = []
    extensions: Optional[dict] = None


class StixSCOModel(BaseModel):
    type: str
    spec_version: Optional[str] = ""
    id: str
    object_marking_refs: Optional[List[str]] = []
    granular_markings: Optional[List[StixGranularMarkingModel]] = []
    defanged: Optional[bool] = False
    extensions: Optional[dict] = None


class StixKillChainPhase(BaseModel):
    kill_chain_name: str
    phase_name: str


##################################################
# STIX Domain Objects


class StixAttackAction(StixSDOModel):
    """An ``attack-action`` object represents the execution of a particular technique,
    i.e. a discrete unit of adverary behavior."""

    id: AttackActionIdentifier
    type: Literal[f"{StixObjectType.attack_action.value}"]
    spec_version: str
    name: str
    # Optional
    description: Optional[str] = ""
    tactic_id: Optional[str] = Field(
        "",
        description="""A tactic identifier or shortname that may reference an 
        authoritative collection of tactics, e.g. ATT&CK.""",
    )
    tactic_ref: Optional[str] = Field(
        "",
        description="""A reference to the tactic’s STIX representation. For ATT&CK, 
        this should be an x-mitre-tactic object.""",
    )
    technique_id: Optional[str] = Field(
        "",
        description="""A technique identifier or shortname that may reference an 
        authoritative collection of techniques, e.g. ATT&CK.""",
    )
    technique_ref: Optional[AttackPatternIdentifier] = Field(
        None,
        description="""A reference to the technique’s STIX representation.""",
    )
    execution_start: Optional[str] = Field(
        "",
        description="""Timestamp indicating when the execution of this action began.""",
    )
    execution_end: Optional[str] = Field(
        "",
        description="""Timestamp indicating when the execution of this action ended.""",
    )
    command_ref: Optional[ProcessIdentifier] = Field(
        None,
        description="""Describe tools or commands executed by the attacker by referring 
        to a STIX Process object, which can represent commands, environment variables, 
        process image, etc.""",
    )
    asset_refs: Optional[List[AttackAssetIdentifier]] = Field(
        [],
        description="""The assets involved in this action, i.e. where this action 
        modifies or depends on the state of the asset.""",
    )
    effect_refs: Optional[List[EffectRefIdentifier]] = Field(
        [],
        description="""The potential effects that result from executing this action.""",
    )


class StixAttackAsset(StixSDOModel):
    """An asset is any object that is the subject or target of an action. Assets can be
    technical assets (such as machines and data) or non-technical assets such as people
    and physical systems. Actions typically either modify or depend upon the *state* of
    an asset in some way.\n\nNote that assets are not applicable in all contexts. For
    example, public threat reports may not include enough detail to represent the assets
    in a flow, or the flow might represent aggregate behavior (at the campaign or actor
    level) for which it does not make sense to specify an asset. Assets should be used
    to add context to a flow when the underlying intelligence contains sufficient detail
    to do so."""

    id: AttackAssetIdentifier
    type: Literal[f"{StixObjectType.attack_asset.value}"]
    spec_version: str
    name: str
    # Optional
    description: Optional[str] = ""
    object_ref: Optional[ObjectRefIdentifier] = Field(
        None,
        description="""A reference to any STIX data object (i.e. SDO) or observable 
        (i.e. SCO) that contains structured data about this asset.""",
    )


class StixAttackCondition(StixSDOModel):
    """An ``attack-condition`` object represents some possible condition, outcome, or
    state that could occur. Conditions can be used to split flows based on the success
    or failure of an action, or to provide further description of an action's results."""

    id: AttackConditionIdentifier
    type: Literal[f"{StixObjectType.attack_condition.value}"]
    spec_version: str
    description: str
    # Optional
    pattern: Optional[str] = Field(
        "",
        description="""(This is an experimental feature.) The detection pattern for this 
        condition may be expressed as a STIX Pattern or another appropriate language such 
        as SNORT, YARA, etc.""",
    )
    pattern_type: Optional[str] = Field(
        "",
        description="""(This is an experimental feature.) The pattern langauge used in this 
        condition. The value for this property should come from the STIX pattern-type-ov 
        open vocabulary.""",
    )
    pattern_version: Optional[str] = Field(
        "",
        description="""(This is an experimental feature.) The version of the pattern 
        language used for the data in the pattern property. For the STIX Pattern language, 
        the default value is determined by the spec_version of the condition object.""",
    )
    on_true_refs: Optional[List[EffectRefIdentifier]] = Field(
        [],
        description="When the condition is ``true``, the flow continues to these objects.",
    )
    on_false_refs: Optional[List[EffectRefIdentifier]] = Field(
        [],
        description="""When the condition is ``false``, the flow continues to these 
        objects. (If there are no objects, then the flow halts at this node.)""",
    )


class StixAttackFlow(StixSDOModel):
    """
    Every Attack Flow document MUST contain exactly one 'attack-flow' object. It
    provides metadata for name and description, starting points for the flow of
    actions, and can be referenced from other STIX objects.
    """

    id: AttackFlowIdentifier
    type: Literal[f"{StixObjectType.attack_flow.value}"]
    spec_version: str
    name: str
    scope: StixScopeType = Field(
        ...,
        description="""Indicates what type of behavior the Attack Flow describes: 
        a specific incident, a campaign, etc.""",
    )
    start_refs: List[StartRefIdentifier] = Field(
        ...,
        description="A list of objects that start the flow.",
    )
    # Optional
    description: Optional[str] = ""

    class Config:
        use_enum_values = True


class StixAttackOperator(StixSDOModel):
    """An ``attack-operator`` object joins multiple attack paths together using boolean
    logic."""

    id: AttackOperatorIdentifier
    type: Literal[f"{StixObjectType.attack_operator.value}"]
    spec_version: str
    operator: StixOperatorType
    # Optional
    effect_refs: Optional[List[EffectRefIdentifier]] = Field(
        [],
        description="""The effects, outcomes, or states that result when this operator 
        evaluates to true. If the operator evaluates to false, then the flow halts. 
        (See: Effects.)""",
    )

    class Config:
        use_enum_values = True


class StixAttackPattern(StixSDOModel):
    id: AttackPatternIdentifier
    type: Literal[StixObjectType.attack_pattern]
    name: str
    description: Optional[str] = ""
    aliases: Optional[List[str]] = []
    kill_chain_phases: Optional[List[StixKillChainPhase]] = []


class StixExtensionDefinition(StixSDOModel):
    id: ExtensionDefinitionIdentifier
    type: Literal[f"{StixObjectType.extension_definition.value}"]
    created_by_ref: IdentityIdentifier
    name: str
    description: Optional[str] = ""
    schema: str
    version: str
    extension_types: List[StixExtensionType]
    extension_properties: Optional[List[str]] = []

    class Config:
        use_enum_values = True


class StixGrouping(StixSDOModel):
    id: GroupIdentifier
    type: Literal[f"{StixObjectType.grouping.value}"]
    context: OpenVocab
    object_refs: List[Identifier] = []
    name: Optional[str] = ""
    description: Optional[str] = ""
    rapids_category: Optional[List[str]] = []


class StixIdentity(StixSDOModel):
    id: IdentityIdentifier
    type: Literal[f"{StixObjectType.identity.value}"]
    name: str
    description: Optional[str] = ""
    roles: Optional[List[str]] = []
    identity_class: Optional[OpenVocab] = ""
    sectors: Optional[List[OpenVocab]] = []
    contact_information: Optional[str] = ""


StixSDOModels = Annotated[
    Union[
        StixAttackAction,
        StixAttackAsset,
        StixAttackCondition,
        StixAttackFlow,
        StixAttackOperator,
        StixAttackPattern,
        StixExtensionDefinition,
        StixGrouping,
        StixIdentity,
    ],
    Field(discriminator="type"),
]


class StixBundle(BaseModel):
    created: Optional[str] = ""
    id: BundleIdentifier
    modified: Optional[str] = ""
    name: Optional[str] = ""
    objects: Optional[List[StixSDOModels]] = []
    spec_version: Optional[str] = ""
    type: Literal["bundle"]
