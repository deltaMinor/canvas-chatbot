from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectADService(DomainRepositoryService):
    """
    A service class that manages Project AD using a RemoteRepository.

    The ProjectADService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Project AD.

    Attributes:
        repository (RemoteRepository): The repository used for managing Project AD.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectADService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Project AD.
        """
        super().__init__(repository=repository)
        self.repository = repository
