from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectService(DomainRepositoryService):
    """
    A service class that manages Projects using a RemoteRepository.

    The ProjectService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Projects.

    Attributes:
        repository (RemoteRepository): The repository used for managing Projects.

    Args:
        repository (RemoteRepository): The repository used for managing Projects.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Projects.
        """
        super().__init__(repository=repository)
        self.repository = repository
