from ....infrastructure.remote_repository.service import RemoteRepository
from ...shared.repository import DomainRepositoryService


class MasterADTemplateService(DomainRepositoryService):
    """
    Service for managing master AD templates.

    This class is responsible for managing the operations related to master AD templates. It interacts with
    the provided repository to fetch, update, delete, and create master AD templates.

    Attributes:
        repository (RemoteRepository): The repository to manage the master AD templates.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the MasterADTemplateService with the given repository.

        Args:
            repository (RemoteRepository): The repository to manage the master AD templates.
        """
        super().__init__(repository=repository)
        self.repository = repository
