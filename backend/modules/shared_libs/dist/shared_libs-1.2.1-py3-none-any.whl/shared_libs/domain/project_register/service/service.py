from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectRegisterService(DomainRepositoryService):
    """
    A service class that manages Project Registrations using a RemoteRepository.

    The ProjectRegisterService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Project Registrations.

    Attributes:
        repository (RemoteRepository): The repository used for managing Project Registrations.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectRegisterService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Project Registrations.
        """
        super().__init__(repository=repository)
        self.repository = repository
