from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class ProjectCQTemplateService(DomainRepositoryService):
    """
    Service class for handling operations related to the Project Conception Questionnaire Template (ProjectCT).

    This class provides an interface for interacting with ProjectCT data in the repository.

    Attributes:
        repository (Repository): The repository where the ProjectCT data is stored.
    """

    def __init__(self, repository: Repository):
        """
        Initializes the ProjectCTService with the given repository.

        Args:
            repository (Repository): The repository where the ProjectCT data is stored.
        """
        super().__init__(repository=repository)
        self.repository = repository
