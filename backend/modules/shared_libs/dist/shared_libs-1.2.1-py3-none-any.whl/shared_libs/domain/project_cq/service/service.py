from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectCQService(DomainRepositoryService):
    """
    A service class that manages Project CQ using a RemoteRepository.

    The ProjectCQService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Project CQ.

    Attributes:
        repository (RemoteRepository): The repository used for managing Project CQ.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectCQService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Project CQ.
        """
        super().__init__(repository=repository)
        self.repository = repository
