from ....domain.shared.repository import DomainRepositoryService
from ....exceptions.api_exceptions import BadRequest
from ....infrastructure.repository.service import Repository
from ....models.database_models import ResourceTagModel


class ResourceTagService(DomainRepositoryService):
    """
    Service for managing resource tags.

    This service provides methods for checking duplicate names in resource tags.

    Attributes:
        repository: An instance of Repository class.
    """

    def __init__(self, repository: Repository):
        """
        Constructs all the necessary attributes for the ResourceTagService object.

        Args:
            repository (Repository): An instance of Repository class.
        """
        super().__init__(repository=repository)
        self.repository = repository

    def check_duplicate_name(self, tag_name: str):
        """
        Checks if a resource tag with the given name already exists.

        This method retrieves all the resource tags and checks if any of them has the same name as the given tag_name.
        If a duplicate is found, it raises a BadRequest exception.

        Args:
            tag_name (str): The name of the resource tag to check.

        Raises:
            BadRequest: If a resource tag with the same name already exists.
        """
        db_resource_tags = self.get_many()
        resource_tag_models = [ResourceTagModel(**_) for _ in db_resource_tags]
        if tag_name in [_.tag_name for _ in resource_tag_models]:
            raise BadRequest(f"Existing Resource Tag <{tag_name}> found.")
