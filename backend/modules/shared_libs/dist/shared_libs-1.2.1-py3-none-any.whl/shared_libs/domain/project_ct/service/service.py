from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectCQTemplateService(DomainRepositoryService):
    """
    A service class that manages Project CQ templates using a RemoteRepository.

    The ProjectCQTemplateService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Project CQ templates.

    Attributes:
        repository (RemoteRepository): The repository used for managing Project CQ templates.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectCQTemplateService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Project CQ templates.
        """
        super().__init__(repository=repository)
        self.repository = repository
