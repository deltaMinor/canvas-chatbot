from ....infrastructure.remote_repository.service import RemoteRepository
from ...shared.repository import DomainRepositoryService


class PriorityRulesService(DomainRepositoryService):
    """
    Service for managing priority rules.

    This service provides methods for managing priority rules in a domain repository.

    Attributes:
        repository: A RemoteRepository instance representing the remote repository.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Constructs all the necessary attributes for the PriorityRulesService object.

        Args:
            repository (RemoteRepository): The remote repository where the priority rules are managed.
        """
        super().__init__(repository=repository)
        self.repository = repository
