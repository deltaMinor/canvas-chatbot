from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectRegisterHistoryService(DomainRepositoryService):
    """
    A service class that manages Project Registration History using a RemoteRepository.

    The ProjectRegisterHistoryService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Project Registration History.

    Attributes:
        repository (RemoteRepository): The repository used for managing Project Registration History.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectRegisterHistoryService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Project Registration History.
        """
        super().__init__(repository=repository)
        self.repository = repository
