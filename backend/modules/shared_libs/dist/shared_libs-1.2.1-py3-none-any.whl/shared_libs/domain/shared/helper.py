from itertools import zip_longest


def batcher(iterable, n):
    args = [iter(iterable)] * n
    return zip_longest(*args)


__all__ = ["batcher"]
