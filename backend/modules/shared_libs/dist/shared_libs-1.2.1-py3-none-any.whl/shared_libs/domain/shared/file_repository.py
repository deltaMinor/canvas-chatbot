from typing import Any, List

from ...decorators.exception import raise_exception
from ...infrastructure.file_repository.service import FileRepository
from ...infrastructure.remote_file_repository.service import RemoteFileRepository


class DomainFileRepositoryService:
    def __init__(self, repository: FileRepository | RemoteFileRepository):
        self.repository = repository

    @raise_exception("Failed to retrieve many files.")
    def get_many_files(
        self,
        query_dict: dict,
        **kwargs,
    ) -> List[dict]:
        return self.repository.find_multiple_files(
            query_dict=query_dict,
            **kwargs,
        )

    @raise_exception("Failed to insert one file.")
    def insert_one_file(
        self,
        query_dict: dict,
        decoded_file: str,
        user_info: dict,
        **kwargs: Any,
    ):
        return self.repository.insert_single_file(
            query_dict=query_dict,
            decoded_file=decoded_file,
            user_info=user_info,
            **kwargs,
        )

    @raise_exception("Failed to delete many files.")
    def delete_many_files(
        self,
        query_dict: dict,
        **kwargs,
    ):
        return self.repository.delete_multiple_files(
            query_dict=query_dict,
            **kwargs,
        )
