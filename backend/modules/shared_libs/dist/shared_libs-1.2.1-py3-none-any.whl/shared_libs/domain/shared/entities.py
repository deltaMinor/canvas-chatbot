from datetime import datetime

from pydantic import BaseModel, Field

from ... import lib_config

TZINFO = lib_config.TZINFO


class MetadataDetails(BaseModel):
    timestamp: datetime = Field(
        default_factory=lambda: datetime.now(TZINFO),
    )
    user_id: str
    username: str


class Metadata(BaseModel):
    created_on: MetadataDetails
    modified_on: MetadataDetails
