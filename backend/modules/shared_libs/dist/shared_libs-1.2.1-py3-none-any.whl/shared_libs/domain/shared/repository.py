from typing import Any, Dict, List, Tuple

from pydantic import BaseModel

from ...decorators.exception import raise_exception
from ...decorators.validation import verify_params
from ...exceptions.api_exceptions import BadRequest, NotFound
from ...infrastructure.remote_repository.service import RemoteRepository
from ...infrastructure.repository.service import Repository
from ...logger.app_logger import logger
from ...models.base_models import (
    CollectionDeleteMultipleModel,
    CollectionQueryModel,
    CollectionUpdateSingleListModel,
    CollectionUpdateSingleModel,
    ParamDictModel,
)

default_projection = {"_id": False}


class DomainRepositoryService:
    """Handles domain-specific database operations.

    This class provides a layer of abstraction over the direct interaction with the database.
    It uses a repository object for performing CRUD operations on a specific domain in the database.

    Attributes:
        repository (Repository | RemoteRepository): An object of either the Repository or RemoteRepository class.
        name (str): The name of the collection or queue the repository is interacting with.
    """

    def __init__(self, repository: Repository | RemoteRepository):
        """Initializes the service with the given repository.

        Args:
            repository (Repository | RemoteRepository): An object of either the Repository or RemoteRepository class.
        """
        self.repository = repository
        if isinstance(repository, Repository):
            self.name = f"{repository.collection.name} collection"
        if isinstance(repository, RemoteRepository):
            self.name = f"{repository.producer.producer_data_model.task_queue} queue"

    @raise_exception("Failed to create param dict model.")
    def get_param_dict_models(
        self,
        filter_key: str,
        data_list: List[Tuple[str, BaseModel]],
    ) -> List[ParamDictModel]:
        """
        Generates a list of ParamDictModel instances from the provided data.

        This method takes a list of tuples, where each tuple contains an ID and a BaseModel instance. It generates a list of ParamDictModel instances, where each instance contains a filter dict and a payload dict. The filter dict contains the provided filter key and the ID, and the payload dict contains the dumped model data.

        Args:
            filter_key (str): The key to be used in the filter dict.
            data_list (List[Tuple[str, BaseModel]]): The list of tuples, where each tuple contains an ID and a BaseModel instance.

        Returns:
            List[ParamDictModel]: The list of ParamDictModel instances generated from the provided data.

        Raises:
            Exception: If an error occurred while generating the ParamDictModel instances.
        """
        param_dict_list = []
        for id, model in data_list:
            param_dict_list.append(
                {
                    "filter": {
                        filter_key: id,
                    },
                    "payload": model.model_dump(),
                }
            )
        return [ParamDictModel(**param_dict) for param_dict in param_dict_list]

    @raise_exception("Failed to retrieve one document from database.")
    def get_one(
        self,
        filter=None,
        raise_if_not_found=False,
        raise_if_found=False,
        *args,
        **kwargs,
    ) -> Any:
        """Retrieves a single document from the database based on the provided filter.

        This method queries the database for a single document that matches the provided filter.
        If `raise_if_not_found` is True and no document is found, a NotFound exception is raised.
        If `raise_if_found` is True and a document is found, a BadRequest exception is raised.

        Args:
            filter (dict, optional): A dictionary specifying the criteria that the document must meet to be retrieved. Defaults to None.
            raise_if_not_found (bool, optional): Whether to raise an exception if no document is found. Defaults to False.
            raise_if_found (bool, optional): Whether to raise an exception if a document is found. Defaults to False.
            *args: Additional arguments to pass to the CollectionQueryModel.
            **kwargs: Additional keyword arguments to pass to the CollectionQueryModel.

        Returns:
            Any: The document retrieved from the database, or None if no document was found and `raise_if_not_found` is False.

        Raises:
            NotFound: If `raise_if_not_found` is True and no document is found.
            BadRequest: If `raise_if_found` is True and a document is found.
        """
        filter = filter or (args[0] if len(args) else None)
        logger.debug(f"[{self.name}] Retrieving a single document ...")
        new_projection = kwargs.get("projection") or {}
        kwargs.update(
            {"projection": {**default_projection, **new_projection}},
        )
        out = self.repository.find_single(
            **CollectionQueryModel(
                **kwargs,
                filter=filter,
            ).model_dump(),
        )

        if raise_if_not_found and out is None:
            raise NotFound(f"Resource not found.")
        if raise_if_found and out is not None:
            raise BadRequest(f"Existing resource found.")
        return out

    @raise_exception("Failed to retrieve multiple documents.")
    def get_many(
        self,
        filter=None,
        raise_if_not_found=False,
        raise_if_found=False,
        *args,
        **kwargs,
    ) -> List[Any] | None:
        """Retrieves multiple documents from the database.

        This method retrieves multiple documents from the database that match the criteria specified by the 'filter' parameter.
        It can optionally raise exceptions if no documents are found or if any documents are found.

        Args:
            filter (dict, optional): A dictionary specifying the criteria that the documents must meet to be retrieved. Defaults to None.
            raise_if_not_found (bool, optional): Whether to raise an exception if no documents are found. Defaults to False.
            raise_if_found (bool, optional): Whether to raise an exception if any documents are found. Defaults to False.
            *args: Additional positional arguments, the first of which is used as the filter if 'filter' is None.
            **kwargs: Additional keyword arguments for the find operation.

        Returns:
            List[Any] | None: The list of documents that were found, or None if no documents were found.

        Raises:
            NotFound: If 'raise_if_not_found' is True and no documents are found.
            BadRequest: If 'raise_if_found' is True and any documents are found.
        """
        filter = filter or (args[0] if len(args) else None)
        logger.debug(f"[{self.name}] Retrieving multiple documents ...")
        new_projection = kwargs.get("projection") or {}
        kwargs.update(
            {"projection": {**default_projection, **new_projection}},
        )
        out = self.repository.find_multiple(
            **CollectionQueryModel(
                **kwargs,
                filter=filter,
            ).model_dump(),
        )

        if raise_if_not_found and (out is None or not len(out)):
            raise NotFound(f"Resource not found.")
        if raise_if_found and (out is not None or len(out) > 0):
            raise BadRequest(f"Existing resource found.")

        return out

    @raise_exception("Failed to update one document.")
    @verify_params(key_list=["filter", "payload", "user_info"])
    def update_one(
        self,
        filter: Dict[str, Any],
        payload: Dict[str, Any],
        user_info: Dict[str, Any],
        **kwargs: Any,
    ) -> Any:
        """Updates a single document in the database.

        This method updates a single document in the database that matches the criteria specified by the 'filter' parameter.
        The new data for the document is provided in the 'payload'. Additional criteria for the update operation can be specified in the kwargs.

        Args:
            filter (Dict[str, Any]): A dictionary specifying the criteria that the document must meet to be updated.
            payload (Dict[str, Any]): The new data for the document.
            user_info (Dict[str, Any]): The user information.
            **kwargs (Any): Additional parameters for the update operation.

        Returns:
            Any: The result of the update operation, which includes the number of documents updated.

        Raises:
            Exception: If an error occurs while trying to update the document.
        """
        logger.debug(f"[{self.name}] Updating a single document ...")
        return self.repository.update_single(
            **CollectionUpdateSingleModel(
                **kwargs,
                filter=filter,
                payload=payload,
                user_info=user_info,
            ).model_dump(),
        )

    @raise_exception("Failed to update document list.")
    @verify_params(key_list=["param_dict_list", "user_info"])
    def update_many_in_list(
        self,
        param_dict_list,
        user_info,
    ) -> Any:
        """
        Updates multiple documents in a list.

        This method will update multiple documents in the database based on the provided list of parameters.
        Each item in the 'param_dict_list' should be a dictionary containing the query parameters and the new data for the update.

        Args:
            param_dict_list (list): A list of dictionaries, each containing the query parameters and the new data for the update.
            user_info (dict): The user information.

        Returns:
            Any: A list of UpdateResult objects, each representing the result of an update operation.
        """
        logger.debug(f"[{self.name}] Updating multiple document in a list ...")
        return self.repository.update_single_list(
            **CollectionUpdateSingleListModel(
                param_dict_list=param_dict_list,
                user_info=user_info,
            ).model_dump(),
        )

    @raise_exception("Failed to delete multiple documents.")
    @verify_params(key_list=["filter"])
    def delete_many(
        self,
        filter,
        **kwargs,
    ) -> Any:
        """
        Deletes multiple documents from the database that match a specified filter.

        This method deletes multiple documents from the database that match the criteria specified by the 'filter' parameter.
        Additional parameters for the deletion operation can be specified in the kwargs.

        Args:
            filter (dict): A dictionary specifying the deletion criteria. Each key-value pair in the dictionary specifies a field and its value that the documents to be deleted should match.
            **kwargs: Additional parameters for the deletion operation. These can include options like 'collation' and 'session'.

        Returns:
            Any: The result of the delete operation, which includes the number of documents deleted. This object has two attributes: 'deleted_count', which gives the number of deleted documents, and 'acknowledged', which indicates whether the delete operation was acknowledged by the server.

        Raises:
            Exception: If an error occurs while trying to delete multiple documents.
        """
        logger.debug(f"[{self.name}] Deleting multiple document ...")
        return self.repository.delete_multiple(
            **CollectionDeleteMultipleModel(
                **kwargs,
                filter=filter,
            ).model_dump(),
        )
