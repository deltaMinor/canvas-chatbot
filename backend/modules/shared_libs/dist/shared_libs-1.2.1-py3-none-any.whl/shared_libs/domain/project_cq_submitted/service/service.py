from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class ProjectCQSubmittedService(DomainRepositoryService):
    """
    A service class that manages submitted Project CQs using a RemoteRepository.

    The ProjectCQSubmittedService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage submitted Project CQs.

    Attributes:
        repository (RemoteRepository): The repository used for managing submitted Project CQs.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the ProjectCQSubmittedService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing submitted Project CQs.
        """
        super().__init__(repository=repository)
        self.repository = repository
