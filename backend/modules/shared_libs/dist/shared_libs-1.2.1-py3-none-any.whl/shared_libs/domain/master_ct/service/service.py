from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class MasterCQTemplateService(DomainRepositoryService):
    """
    A service class that manages Master CQ templates using a RemoteRepository.

    The MasterCQTemplateService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Master CQ templates.

    Attributes:
        repository (RemoteRepository): The repository used for managing Master CQ templates.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the MasterCQTemplateService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Master CQ templates.
        """
        super().__init__(repository=repository)
        self.repository = repository
