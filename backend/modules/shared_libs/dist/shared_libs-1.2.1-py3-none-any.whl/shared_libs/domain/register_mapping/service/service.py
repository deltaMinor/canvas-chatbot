from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class RegisterMappingService(DomainRepositoryService):
    """
    Service class for RegisterMapping operations. Inherits from DomainRepositoryService.

    Attributes:
        repository (Repository): The repository object that this service will use to perform operations.
    """

    def __init__(self, repository: Repository):
        """
        Initialize the RegisterMappingService with a given repository.

        Args:
            repository (Repository): The repository object to perform operations with.
        """
        self.repository = repository
        super().__init__(repository=repository)

    def get_register_mapping_dict(self) -> dict:
        register_mapping_list = self.get_one(raise_if_not_found=True).get("register_mapping")
        register_mapping_dict = {}
        for obj in register_mapping_list:
            riskScenarioId = obj["riskScenarioId"]
            register_mapping_dict[riskScenarioId] = {"IM8": [], "ATT&CK": []}

            knowledgeBases = obj["knowledgeBases"]
            for kb in knowledgeBases:
                if kb["source"] == "IM8":
                    register_mapping_dict[riskScenarioId]["IM8"] = kb["id"]
                elif kb["source"] == "ATT&CK":
                    register_mapping_dict[riskScenarioId]["ATT&CK"] = kb["id"]

        return register_mapping_dict
