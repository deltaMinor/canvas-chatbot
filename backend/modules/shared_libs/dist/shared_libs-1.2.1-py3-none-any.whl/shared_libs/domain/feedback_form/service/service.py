from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class FeedbackFormService(DomainRepositoryService):
    """
    A service class that manages Feedback Form submissions using a RemoteRepository.

    The FeedbackFormSerivice class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Feedback Form submissions.

    Attributes:
        repository (RemoteRepository): The repository used for managing Feedback Form submissions.

    Args:
        repository (RemoteRepository): The repository used for managing Feedback Form submissions.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the FeedbackFormSerivice with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Feedback Form submissions.
        """
        super().__init__(repository=repository)
        self.repository = repository
