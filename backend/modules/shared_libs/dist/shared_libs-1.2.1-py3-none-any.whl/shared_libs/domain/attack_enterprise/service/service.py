from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class AttackEnterpriseService(DomainRepositoryService):
    """
    Service class for AttackEnterprise operations. Inherits from DomainRepositoryService.

    Attributes:
        repository (Repository): The repository object that this service will use to perform operations.
    """

    def __init__(self, repository: Repository):
        """
        Initialize the AttackEnterpriseService with a given repository.

        Args:
            repository (Repository): The repository object to perform operations with.
        """
        super().__init__(repository=repository)
        self.repository = repository
