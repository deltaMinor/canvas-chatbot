from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class MasterRegisterLogService(DomainRepositoryService):
    """
    A service class for handling master register log operations.

    This class provides methods to interact with the master register log repository. It inherits from the DomainRepositoryService class.

    Attributes:
        repository (Repository): The repository to interact with.
    """

    def __init__(self, repository: Repository):
        """
        Constructs all the necessary attributes for the MasterRegisterLogService object.

        Args:
            repository (Repository): The repository to interact with.
        """
        super().__init__(repository=repository)
        self.repository = repository
