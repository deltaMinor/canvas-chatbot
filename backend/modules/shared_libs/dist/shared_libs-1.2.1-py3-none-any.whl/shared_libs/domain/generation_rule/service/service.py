from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class GenerationRuleService(DomainRepositoryService):
    """
    Service class for GenerationRule operations. Inherits from DomainRepositoryService.

    Attributes:
        repository (Repository): The repository object that this service will use to perform operations.
    """

    def __init__(self, repository: Repository):
        """
        Initialize the GenerationRuleService with a given repository.

        Args:
            repository (Repository): The repository object to perform operations with.
        """
        super().__init__(repository=repository)
        self.repository = repository
