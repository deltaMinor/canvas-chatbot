from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class MasterCQService(DomainRepositoryService):
    """
    A service class that manages Master CQs using a RemoteRepository.

    The MasterCQService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage Master CQs.

    Attributes:
        repository (RemoteRepository): The repository used for managing Master CQs.

    Args:
        repository (RemoteRepository): The repository used for managing Master CQs.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the MasterCQService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing Master CQs.
        """
        super().__init__(repository=repository)
        self.repository = repository
