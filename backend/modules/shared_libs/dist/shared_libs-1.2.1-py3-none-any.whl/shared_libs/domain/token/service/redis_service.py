from ....decorators.exception import raise_exception
from ....decorators.validation import verify_params
from ....infrastructure.redis_repository.service import RedisRepository
from ....logger.app_logger import logger
from ....models.database_models import AuthenticationModel
from ...shared.redis_repository import DomainRedisRepositoryService


class TokenRedisService(DomainRedisRepositoryService):
    """
    Handles token-related operations in Redis.

    Provides methods to save, retrieve, and delete tokens in Redis.

    Attributes:
        redis_repository (RedisRepository): The Redis repository used for token operations.
    """

    def __init__(self, redis_repository: RedisRepository):
        """
        Initializes TokenRedisService with a Redis repository.

        Args:
            redis_repository (RedisRepository): The Redis repository used for token operations.
        """
        super().__init__(redis_repository=redis_repository)

    @raise_exception("An error occurred while retrieving authentication model dict.")
    @verify_params(key_list=["encoded_token"])
    def get_authentication_model_dict(self, encoded_token: str, **kwargs) -> str | None:
        """
        Retrieves an authentication model dictionary from Redis.

        This method retrieves the authentication model dictionary associated with the provided encoded token from Redis.

        Args:
            encoded_token (str): The encoded token associated with the authentication model dictionary to be retrieved.
            **kwargs: Additional parameters for the retrieval operation. These can include options like 'type' and 'count'.

        Returns:
            str | None: The authentication model dictionary if it exists, None otherwise.

        Raises:
            Exception: If an error occurs while trying to retrieve the authentication model dictionary.
        """
        return self.get_item(
            name=f"encoded_token:{encoded_token}",
        )

    @raise_exception("An error occurred while saving token.")
    @verify_params(key_list=["authentication_model"])
    def save_authentication_model_in_redis(
        self,
        authentication_model: AuthenticationModel,
        **kwargs,
    ) -> bool | None:
        """
        Saves the authentication model in Redis.

        This method saves the given authentication model in Redis with a key that includes the encoded token.
        The expiry time for the token is set to the value of 'REDIS_TOKEN_EXPIRY' in kwargs, or 600 seconds by default.

        Args:
            authentication_model (AuthenticationModel): The authentication model to be saved in Redis.
            **kwargs: Arbitrary keyword arguments.

        Returns:
            bool | None: True if the operation was successful, None otherwise.

        Raises:
            Exception: If the save operation fails.
        """
        return self.set_item(
            name=f"encoded_token:{authentication_model.encoded_token}",
            mapping=authentication_model.model_dump(),
            expiry=kwargs.get("REDIS_TOKEN_EXPIRY", 600),
            mapping_list=[{"user_id": authentication_model.decoded_token.user_id}],
            **kwargs,
        )

    @raise_exception("An error occurred while deleting tokens.")
    @verify_params(key_list=["user_id"])
    def delete_decoded_tokens(
        self,
        user_id: str,
        **kwargs,
    ):
        """
        Deletes decoded tokens for a specific user.

        This method deletes all decoded tokens associated with the user specified by the 'user_id' parameter.
        It searches for tokens using the pattern "encoded_token:*" and the provided user ID.

        Args:
            user_id (str): The ID of the user whose tokens are to be deleted.
            **kwargs: Additional parameters for the deletion operation. These can include options like 'count' and 'type'.

        Returns:
            int: The number of tokens deleted.

        Raises:
            Exception: If an error occurs while trying to delete the tokens.
        """
        return self.delete_items(
            patterns=["encoded_token:*"],
            mapping={"user_id": user_id},
            **kwargs,
        )
