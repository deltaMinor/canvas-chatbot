from ....infrastructure.repository.service import Repository
from ...shared.repository import DomainRepositoryService


class TokenService(DomainRepositoryService):
    """
    A class used to handle token related tasks.

    This class is responsible for managing tokens. It can retrieve or create token models and JWT dictionary models.

    Attributes:
        repository (Repository): The repository object to perform operations with.

    Methods:
        get_token_model(user_model: UserModel, token_type: str, encrypted_token: str) -> TokenModel:
            Retrieves or creates a token model.
        get_jwt_dict_model(user_model: UserModel, JWT_LIFE_HOUR=1) -> JwtDictModel:
            Retrieves a JWT dictionary model.
    """

    def __init__(self, repository: Repository):
        """
        Initialize the TokenService with a given repository.

        Args:
            repository (Repository): The repository object to perform operations with.
        """
        super().__init__(repository=repository)
        self.repository = repository
