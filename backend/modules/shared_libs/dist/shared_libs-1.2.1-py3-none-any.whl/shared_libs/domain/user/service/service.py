from ....domain.shared.repository import DomainRepositoryService
from ....infrastructure.remote_repository.service import RemoteRepository


class UserService(DomainRepositoryService):
    """
    A service class that manages User data using a RemoteRepository.

    The UserService class extends the DomainRepositoryService and uses a RemoteRepository
    to manage User data.

    Attributes:
        repository (RemoteRepository): The repository used for managing User data.
    """

    def __init__(self, repository: RemoteRepository):
        """
        Initializes the UserService with a RemoteRepository.

        Args:
            repository (RemoteRepository): The repository used for managing User data.
        """
        super().__init__(repository=repository)
        self.repository = repository
