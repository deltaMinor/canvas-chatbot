import uuid
from typing import Any, List

from pydantic import BaseModel, Field, Json

from service.domain.group.entities.entities import Group
from service.domain.shared.entities import Metadata


class User_Entitlement(BaseModel):
    project_id: str
    project_name: str
    project_group: Group


class User(BaseModel):
    user_id: uuid.UUID = Field(default_factory=lambda: f"user_{uuid.uuid4()}")
    user_status: str = ""
    username: str = ""
    password: str = ""
    email: str = ""  # use EmailStr
    groups: List[Group] = []
    roles: List[str] = []
    entitlements: List[str] = []
    notifications: List[Json[Any]] = []
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
    metadata: Metadata = None
