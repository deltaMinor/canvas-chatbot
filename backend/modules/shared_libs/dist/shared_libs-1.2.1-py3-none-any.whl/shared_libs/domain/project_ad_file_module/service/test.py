import unittest
from unittest.mock import patch

from common.types.enum import User
from service.domain.project_ad.service.service import ProjectADService


class TestProjectADRepositoryService(unittest.TestCase):
    @patch("service.infrastructure.repository.service.Repository")
    def test_get_one(self, mock_collection):
        # Arrange
        service = ProjectADService(collection=mock_collection)
        mock_collection.find_single.return_value = {"key": "value"}
        query_dict = {"query": "query_value"}

        # Act
        result = service.get_one(query_dict)

        # Assert
        mock_collection.find_single.assert_called_once_with(
            query_dict,
            project_dict=None,
            extra_pop_dict=None,
        )
        self.assertEqual(result, {"key": "value"})

    @patch("service.infrastructure.repository.service.Repository")
    def test_get_many(self, mock_collection):
        # Arrange
        service = ProjectADService(collection=mock_collection)
        mock_collection.find_multiple.return_value = [
            {"key": "value1"},
            {"key": "value2"},
        ]
        query_dict = {"query": "query_value"}

        # Act
        result = service.get_many(query_dict)

        # Assert
        mock_collection.find_multiple.assert_called_once_with(
            query_dict,
            project_dict=None,
            extra_pop_dict=None,
            sort_key=None,
        )
        self.assertEqual(result, [{"key": "value1"}, {"key": "value2"}])

    @patch("service.infrastructure.repository.service.Repository")
    def test_update_one(self, mock_collection):
        # Arrange
        service = ProjectADService(collection=mock_collection)
        mock_collection.update_single.return_value = {"key": "updated_value"}
        query_dict = {"query": "query_value"}
        payload = {"key": "new_value"}
        user_info = {
            User.user_id.value: "token_user_id",
            User.username.value: "token_username",
        }
        # Act
        result = service.update_one(
            query_dict,
            payload=payload,
            user_info=user_info,
        )

        # Assert
        mock_collection.update_single.assert_called_once()
        self.assertEqual(result, {"key": "updated_value"})
