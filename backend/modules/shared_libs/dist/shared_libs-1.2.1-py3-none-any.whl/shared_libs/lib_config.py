import os

import pytz

# var from environment
BROKER_URL = os.environ.get("BROKER_URL", "amqp://guest:guest@rabbitmq:5672//")
CELERY_REDIS_BACKEND_URL = os.environ.get("CELERY_REDIS_BACKEND_URL", "redis://redis:6379/0")
DB_NAME = os.environ.get("DB_NAME")
DB_PORT = os.environ.get("DB_PORT")
DB_URL = os.environ.get("DB_URL")
REDIS_HOSTNAME = os.environ.get("REDIS_HOSTNAME", "redis")
REDIS_PORT = os.environ.get("REDIS_PORT", 6379)

# Time Zone
LOCAL_TIMEZONE = os.environ.get("LOCAL_TIMEZONE", "Asia/Singapore")
TZINFO = pytz.timezone(LOCAL_TIMEZONE)

#
METADATA_SIZE_MAX = 500
METADATA_SIZE_RETURN = 5
PBKDF2HMAC_ITERATIONS = 600000
PBKDF2HMAC_LENGTH = 32
PBKDF2HMAC_SCHEME = "pbkdf2_sha256"
REDIS_DEFAULT_EXPIRY = 60
REDIS_DOC_EXPIRY = 2592000
REDIS_RESULT_EXPIRY = 10
REDIS_TOKEN_EXPIRY = 600
TASK_DEFAULT_RETRY_DELAY = 0
TASK_EXPIRES = 60
TASK_MAX_RETRIES = 0
TASK_SOFT_TIME_LIMIT = 50
TASK_TIME_LIMIT = 60
TASK_WAIT_RESULT_TIMEOUT = 30

#
FROM_EMAIL = "tm_support@iarcs-create.edu.sg"
TO_EMAIL = "tm_admin@iarcs-create.edu.sg"
TEMPLATE_ID = "d-a9901114c9d548c48b092b7900377788"
