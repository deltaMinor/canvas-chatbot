CUSTOM_LOGGING = {
    "version": 1,
    "disable_existing_loggers": False,
    "formatters": {
        "verbose": {
            "format": "{name} {levelname} {asctime} {module} {process:d} {thread:d} {message}",
            "style": "{",
        },
        "simple": {
            "()": "colorlog.ColoredFormatter",
            "format": "[%(asctime)s %(log_color)s%(levelname)-8s%(reset)s] %(message)s <%(name)s>",
            "datefmt": "%Y-%m-%d %H:%M:%S",
            "style": "%",
            "log_colors": {
                "DEBUG": "white",
                "INFO": "blue",
                "WARNING": "yellow",
                "ERROR": "red",
                "CRITICAL": "bold_red",
            },
        },
        "simple-reduced": {
            "format": "%(message)s <%(name)s>",
            "style": "%",
        },
        "simple_white": {
            "format": "[%(asctime)s %(levelname)-8s] %(message)s <%(name)s>",
            "style": "%",
        },
    },
    "handlers": {
        "console": {
            "level": "INFO",
            "class": "logging.StreamHandler",
            "formatter": "simple",
        },
        "file": {
            "level": "DEBUG",
            "class": "logging.FileHandler",
            "filename": "server.log",
            "formatter": "simple_white",
        },
    },
    "root": {
        "handlers": ["console", "file"],
        "level": "DEBUG",
    },
    "loggers": {
        "logger.app_logger": {
            "level": "DEBUG",
            "handlers": ["file", "console"],
            "propagate": True,
        },
        "celery": {
            "level": "WARN",
            "handlers": ["file", "console"],
            "propagate": True,
        },
        "django": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.request": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.server": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.template": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.db.backends": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.security": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.db.backends.schema": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "django.utils.autoreload": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "passlib.registry": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "passlib.utils.compat": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "python_http_client.client": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "amqp": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
        "kombu": {
            "level": "INFO",
            "handlers": ["console", "file"],
            "propagate": False,
        },
    },
}

COLORS = {
    "WARNING": "YELLOW",
    "INFO": "WHITE",
    "DEBUG": "BLUE",
    "CRITICAL": "YELLOW",
    "ERROR": "RED",
}
