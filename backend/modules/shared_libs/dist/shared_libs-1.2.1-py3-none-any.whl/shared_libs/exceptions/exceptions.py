from ..logger.app_logger import logger


class AttributeValueError(Exception):
    """
    Custom exception raised when the value of an attribute is invalid.
    """

    def __init__(self, key="unknown"):
        """
        Initializes the AttributeValueError exception.

        Args:
            key (str, optional): The key of the attribute that has an invalid value. Defaults to "unknown".
        """
        message = f"The value for the attribute '{key}' is invalid."
        logger.debug(f"AttributeValueError: {message}")
        super().__init__(message)


class DictionaryKeyError(Exception):
    """
    Custom exception raised when a required key is missing from a dictionary.
    """

    def __init__(self, key="unknown"):
        """
        Initialize DictionaryKeyError with a specific key.

        Args:
            key (str, optional): The key that is missing from the dictionary. Defaults to "unknown".
        """
        message = f"The required key '{key}' is missing from the dictionary."
        logger.debug(f"DictionaryKeyError: {message}")
        super().__init__(message)


class DictionaryValueError(Exception):
    """
    Custom exception raised when the value for a specific dictionary key is invalid.
    """

    def __init__(self, key="unknown"):
        """
        Initialize DictionaryValueError with a specific key.

        Args:
            key (str, optional): The key in the dictionary that has an invalid value. Defaults to "unknown".
        """
        message = f"The value for the dictionary key '{key}' is not valid."
        logger.debug(f"DictionaryValueError: {message}")
        super().__init__(message)


class HeaderKeyError(Exception):
    """
    Custom exception raised when a required key is missing from the header.
    """

    def __init__(self, key="unknown"):
        """
        Initialize HeaderKeyError with a specific key.

        Args:
            key (str, optional): The key that is missing from the header. Defaults to "unknown".
        """
        message = f"The required key '{key}' is missing from header."
        logger.debug(f"HeaderKeyError: {message}")
        super().__init__(message)


class HeaderValueError(Exception):
    """
    Custom exception raised when the value for a header key is either None, empty, incorrectly formatted, or of the wrong type.
    """

    def __init__(self, key="unknown"):
        """
        Initialize HeaderValueError with a specific key.

        Args:
            key (str, optional): The key in the header that has an invalid value. Defaults to "unknown".
        """
        message = f"The value for header key '{key}' is invalid."
        logger.debug(f"HeaderValueError: {message}")
        super().__init__(message)


__all__ = [
    "AttributeValueError",
    "DictionaryKeyError",
    "DictionaryValueError",
    "HeaderKeyError",
    "HeaderValueError",
]
