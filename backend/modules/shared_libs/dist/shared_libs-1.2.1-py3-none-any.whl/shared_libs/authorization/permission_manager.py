import json
import os

from ..decorators.exception import raise_exception


class PermissionManager:
    """
    A class used to manage user and admin permissions.

    This class provides methods to retrieve user and admin permissions from a JSON file and properties to access these permissions in a dictionary or list format.

    Attributes:
        user_permission_dict (dict): A dictionary of user permissions.
        admin_permission_dict (dict): A dictionary of admin permissions.
        admin_permission_list (list): A list of admin permissions.
    """

    def __init__(self):
        """
        Constructs all the necessary attributes for the PermissionManager object.
        """
        pass

    @property
    def user_permission_dict(self) -> dict:
        return self.get_user_permission_dict()

    @property
    def admin_permission_dict(self) -> dict:
        return self.get_admin_permission_dict()

    @property
    def admin_permission_list(self) -> dict:
        return self.get_admin_permission_list()

    @raise_exception("Failed to retrieve admin permission dict.")
    def get_admin_permission_dict(self):
        """
        Retrieves the admin permissions from the user permission dictionary.

        This method extracts the admin permissions related to user, project, and resource tag from the user permission
        dictionary and returns them as a new dictionary.

        Returns:
            dict: A dictionary containing the admin permissions.
        """
        return {
            "admin_user": self.user_permission_dict.get("admin_user"),
            "admin_project": self.user_permission_dict.get("admin_project"),
            "admin_resource_tag": self.user_permission_dict.get("admin_resource_tag"),
        }

    @raise_exception("Failed to retrieve admin permission list.")
    def get_admin_permission_list(self):
        """
        Retrieves the admin permissions from the admin permission dictionary as a list.

        This method extracts the admin permissions from the admin permission dictionary and returns them as a list.
        It only includes the permissions that are strings.

        Returns:
            list: A list containing the admin permissions.
        """
        return [
            __
            for _ in self.admin_permission_dict.values()
            for __ in _.values()
            if __ and isinstance(__, str)
        ]

    @staticmethod
    @raise_exception("Failed to retrieve user permission dict.")
    def get_user_permission_dict():
        """
        Retrieves the user permissions from a JSON file.

        This method reads a JSON file named "permissions.json" located in the same directory as this script. It
        returns the contents of this file as a dictionary.

        Returns:
            dict: A dictionary containing the user permissions.
        """
        dir_path = os.path.dirname(os.path.realpath(__file__))
        with open(os.path.join(dir_path, "permissions.json")) as json_file:
            return json.load(json_file)
