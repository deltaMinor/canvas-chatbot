from functools import cached_property
from typing import Any, Dict, List, Optional

from ..decorators.exception import raise_exception
from ..decorators.validation import verify_params
from ..domain.project.service.service import ProjectService
from ..domain.user.service.service import UserService
from ..exceptions.api_exceptions import BadRequest, Unauthorized
from ..infrastructure.producer.service import Producer
from ..infrastructure.remote_repository.service import RemoteRepository
from ..models.base_models import ProducerDataModel
from ..models.database_models import ProjectModel, UserModel
from ..producers.authentication_producer import AuthenticationProducer
from ..producers.producer_data import producer_data_project, producer_data_user
from .permission_manager import PermissionManager


class AuthorizationManager:
    """
    A manager class for handling authorization operations.

    This class provides methods to manage user permissions and field permissions. It uses an AuthenticationProducer to interact with the authentication model and a ProjectService and UserService to interact with the project and user data.

    Attributes:
        auth_producer (AuthenticationProducer): The AuthenticationProducer used to interact with the authentication model.
        permissions (List[str], optional): A list of permissions for the user. Defaults to an empty list.
        field_permissions (List[str], optional): A list of field permissions for the user. Defaults to an empty list.
        user_model (UserModel): The user model from the authentication model.
        unique_permissions (List[str]): The unique permissions from the authentication model.
        resource_tag_tree_models (List[ResourceTagTreeModel]): The resource tag tree models from the authentication model.
        project_service (ProjectService): The service used to interact with the project data.
        user_service (UserService): The service used to interact with the user data.

    Note:
        This class currently does not have any methods.
        Methods should be added as needed in the future.
    """

    def __init__(
        self,
        auth_producer: AuthenticationProducer,
        permissions: Optional[List[str]] = [],
        field_permissions: Optional[List[str]] = [],
    ):
        """
        Constructs all the necessary attributes for the AuthorizationManager object.

        Args:
            auth_producer (AuthenticationProducer): The AuthenticationProducer used to interact with the authentication model.
            permissions (List[str], optional): A list of permissions for the user. Defaults to an empty list.
            field_permissions (List[str], optional): A list of field permissions for the user. Defaults to an empty list.
        """
        self.auth_producer = auth_producer
        self.permissions = permissions
        self.field_permissions = field_permissions

        self.user_model = auth_producer.authentication_model.user
        self.unique_permissions = auth_producer.authentication_model.unique_permissions
        self.resource_tag_tree_models = auth_producer.resource_tag_tree_models

        self.project_service = ProjectService(
            repository=RemoteRepository(
                producer=Producer(
                    producer_data_model=ProducerDataModel(
                        **producer_data_project,
                    ),
                    celery_app=auth_producer.producer.celery_app,
                ),
            ),
        )
        self.user_service = UserService(
            repository=RemoteRepository(
                producer=Producer(
                    producer_data_model=ProducerDataModel(
                        **producer_data_user,
                    ),
                    celery_app=auth_producer.producer.celery_app,
                ),
            )
        )

    @property
    def authorized_tag_id_list(self) -> List[str]:
        return self.get_authorized_tag_id_list()

    @property
    def entitled_tag_id_list(self) -> List[str]:
        return self.get_entitled_tag_id_list()

    @cached_property
    def authorized_project_models(self) -> List[ProjectModel]:
        return self.get_authorized_project_models()

    @cached_property
    def entitled_project_models(self) -> List[ProjectModel]:
        return self.get_entitled_project_models()

    @property
    def authorized_project_id_list(self) -> List[str]:
        return [_.project_id for _ in self.authorized_project_models]

    @property
    def entitled_project_id_list(self) -> List[str]:
        return [_.project_id for _ in self.entitled_project_models]

    @cached_property
    def authorized_user_models(self) -> List[UserModel]:
        return self.get_authorized_user_models()

    @cached_property
    def entitled_user_models(self) -> List[UserModel]:
        return self.get_entitled_user_models()

    @property
    def authorized_user_id_list(self) -> List[str]:
        return [_.user_id for _ in self.authorized_user_models]

    @property
    def entitled_user_id_list(self) -> List[str]:
        return [_.user_id for _ in self.entitled_user_models]

    @property
    def project_authorization_mapping(self) -> dict:
        return self.get_project_authorization_mapping()

    @property
    def project_entitlement_mapping(self) -> dict:
        return self.get_project_entitlement_mapping()

    @property
    def is_admin(self) -> bool:
        return self.verify_admin_in_entitlements()

    @raise_exception(
        "Failed to verify admin privileges in entitlements.",
        default_exception=Unauthorized,
    )
    def verify_admin_in_entitlements(
        self,
        raise_if_not_admin=False,
    ) -> bool:
        """
        Checks if the user has admin privileges in their entitlements.

        This method checks if the user is a superuser or if any of the user's entitlements' permissions
        are in the admin permission list. If `raise_if_not_admin` is True and the user is not an admin,
        an Unauthorized exception is raised.

        Args:
            raise_if_not_admin (bool, optional): Determines whether to raise an exception if the user
            is not an admin. Defaults to False.

        Returns:
            bool: True if the user has admin privileges, False otherwise.

        Raises:
            Unauthorized: If `raise_if_not_admin` is True and the user does not have admin privileges.
        """
        # Check if the user is a superuser
        # If so, return True as they have admin privileges
        if self.user_model.is_superuser:
            return True

        # Iterate over the user's entitlements, and if any of the entitlement's permissions are in the admin permission list, return True indicating the user has admin privileges.
        for entitlement in self.user_model.entitlements:
            if any(p in PermissionManager().admin_permission_list for p in entitlement.permissions):
                return True

        # If raise_if_not_admin is True and the user is not an admin, raise an Unauthorized exception
        if raise_if_not_admin:
            raise Unauthorized("User does not have admin privileges.")
        return False

    @raise_exception("Failed to append child nodes.")
    @verify_params(key_list=["tag_id_list"])
    def append_child_nodes(
        self,
        tag_id_list: List[str],
    ) -> None:
        """
        Appends child nodes to the given tag id list.

        This method iterates over the tag_id_list and for each tag_id, it finds the corresponding
        child nodes from the resource_tag_tree_models. If child nodes are found, they are appended
        to the tag_id_list.

        Args:
            tag_id_list (List[str]): The list of tag ids to which child nodes will be appended.

        Raises:
            Exception: If the tag_id_list parameter is not provided or is not a list.
        """
        if not len(tag_id_list):
            return

        for tag_id in tag_id_list:
            child_nodes = next(
                (_.child_nodes for _ in self.resource_tag_tree_models if _.tag_id == tag_id),
                [],
            )
            if not len(child_nodes):
                continue
            tag_id_list.extend(child_nodes)

    @raise_exception("Failed to retrieve tag id list from permissions.")
    def get_tag_id_list_from_permissions(
        self,
        ref_permissions: List[str],
    ) -> List[str]:
        """
        Retrieves a list of tag ids from the user's entitlements based on the given permissions.

        If no permissions are provided, it returns a list of tag ids from all of the user's entitlements.
        If permissions are provided, it filters the user's entitlements based on these permissions and
        returns a list of the corresponding tag ids. If resource_tag_tree_models are available, it also
        appends any child nodes to the tag id list.

        Args:
            ref_permissions (List[str]): The permissions to filter the user's entitlements by.

        Returns:
            List[str]: A list of tag ids from the user's entitlements based on the given permissions.

        Raises:
            Exception: If there is a failure in retrieving the tag id list from permissions.
        """
        if not ref_permissions or not len(ref_permissions):
            tag_id_list = [_.tag_id for _ in self.user_model.entitlements]
        else:
            tag_id_list = [
                _.tag_id
                for _ in self.user_model.entitlements
                if any(p in _.permissions for p in ref_permissions)
            ]
        if not len(self.resource_tag_tree_models):
            return tag_id_list

        self.append_child_nodes(tag_id_list=tag_id_list)
        return list(set(tag_id_list))

    @raise_exception("Failed to retrieve authorized tag id list.")
    def get_authorized_tag_id_list(self) -> List[str]:
        """
        Retrieves a list of tag ids that the user is authorized for.

        This method calls the get_tag_id_list_from_permissions method with the permissions attribute
        of the AuthorizationManager instance.

        Returns:
            List[str]: A list of tag ids that the user is authorized for.

        Raises:
            Exception: If there is a failure in retrieving the authorized tag id list.
        """
        return self.get_tag_id_list_from_permissions(
            ref_permissions=self.permissions,
        )

    @raise_exception("Failed to retrieve entitled tag id list.")
    def get_entitled_tag_id_list(self) -> List[str]:
        """
        Retrieves a list of entitled tag ids.

        This method calls the get_tag_id_list_from_permissions method with an empty reference permissions
        list and returns the resulting list of tag ids.

        Returns:
            List[str]: A list of entitled tag ids.

        Raises:
            Exception: If there is a failure in retrieving the entitled tag id list.
        """
        return self.get_tag_id_list_from_permissions(
            ref_permissions=[],
        )

    @raise_exception("Failed to retrieve project models from tag id list.")
    def get_project_models_from_tag_id_list(
        self,
        ref_tag_id_list: List[str],
    ) -> List[ProjectModel]:
        """
        Retrieves a list of project models that have any of the given tag ids.

        This method queries the project service for projects that have any of the given tag ids in their
        resource tags. It then converts the returned projects to ProjectModel instances and returns them.

        Args:
            ref_tag_id_list (List[str]): The tag ids to retrieve project models for.

        Returns:
            List[ProjectModel]: A list of project models that have any of the given tag ids.

        Raises:
            Exception: If there is a failure in retrieving the project models from the tag id list.
        """
        db_projects = self.project_service.get_many(
            {
                "resource_tags": {
                    "$elemMatch": {"$in": ref_tag_id_list},
                },
            }
        )
        return [ProjectModel(**_) for _ in db_projects]

    @raise_exception("Failed to retrieve authorized project models.")
    def get_authorized_project_models(self) -> List[ProjectModel]:
        """
        Retrieves a list of project models that the user is authorized for.

        This method calls the get_project_models_from_tag_id_list method with the authorized_tag_id_list
        attribute of the AuthorizationManager instance.

        Returns:
            List[ProjectModel]: A list of project models that the user is authorized for.

        Raises:
            Exception: If there is a failure in retrieving the authorized project models.
        """
        return self.get_project_models_from_tag_id_list(
            ref_tag_id_list=self.authorized_tag_id_list,
        )

    @raise_exception("Failed to retrieve entitled project models.")
    def get_entitled_project_models(self) -> List[ProjectModel]:
        """
        Retrieves a list of entitled project models.

        This method calls the get_project_models_from_tag_id_list method with the entitled tag id list
        and returns the resulting list of project models.

        Returns:
            List[ProjectModel]: A list of entitled project models.

        Raises:
            Exception: If there is a failure in retrieving the entitled project models.
        """
        return self.get_project_models_from_tag_id_list(
            ref_tag_id_list=self.entitled_tag_id_list,
        )

    @raise_exception("Failed to retrieve user models from tag id list.")
    def get_user_models_from_tag_id_list(
        self,
        ref_tag_id_list: List[str],
    ) -> List[UserModel]:
        """
        Retrieves a list of user models that have any of the given tag ids in their entitlements.

        This method queries the user service for users that have any of the given tag ids in their
        entitlements. It then converts the returned users to UserModel instances and returns them.

        Args:
            ref_tag_id_list (List[str]): The tag ids to retrieve user models for.

        Returns:
            List[UserModel]: A list of user models that have any of the given tag ids in their entitlements.

        Raises:
            Exception: If there is a failure in retrieving the user models from the tag id list.
        """
        db_users = self.user_service.get_many(
            {
                "entitlements": {
                    "$elemMatch": {"tag_id": {"$in": ref_tag_id_list}},
                },
            }
        )
        return [UserModel(**_) for _ in db_users]

    @raise_exception("Failed to retrieve authorized user models.")
    def get_authorized_user_models(self) -> List[UserModel]:
        """
        Retrieves a list of user models that the user is authorized for.

        This method calls the get_user_models_from_tag_id_list method with the authorized_tag_id_list
        attribute of the AuthorizationManager instance.

        Returns:
            List[UserModel]: A list of user models that the user is authorized for.

        Raises:
            Exception: If there is a failure in retrieving the authorized user models.
        """
        return self.get_user_models_from_tag_id_list(
            ref_tag_id_list=self.authorized_tag_id_list,
        )

    @raise_exception("Failed to retrieve entitled user models.")
    def get_entitled_user_models(self) -> List[UserModel]:
        """
        Retrieves a list of entitled user models.

        This method calls the get_user_models_from_tag_id_list method with the entitled tag id list
        and returns the resulting list of user models.

        Returns:
            List[UserModel]: A list of entitled user models.

        Raises:
            Exception: If there is a failure in retrieving the entitled user models.
        """
        return self.get_user_models_from_tag_id_list(
            ref_tag_id_list=self.entitled_tag_id_list,
        )

    @raise_exception("Failed to retrieve project permissions.")
    @verify_params(key_list=["project_id"])
    def get_project_permissions(
        self,
        project_id: str,
        project_models: List[ProjectModel],
    ) -> List[str]:
        """
        Retrieves a sorted list of unique permissions for a given project id.

        This method finds the project model with the given project id in the provided project models
        list. It then filters the user's entitlements based on the project model's resource tags. For
        each of these entitlements, it retrieves the permissions that start with "project_" and adds
        them to a list. It then removes duplicates from this list, sorts it, and returns it.

        Args:
            project_id (str): The id of the project to retrieve permissions for.
            project_models (List[ProjectModel]): A list of project models to search for the given
                                                project id.

        Returns:
            List[str]: A sorted list of unique permissions for the given project id.

        Raises:
            Exception: If there is a failure in retrieving the project permissions.
        """
        project_model = next(_ for _ in project_models if _.project_id == project_id)
        filtered_entitlements = [
            _ for _ in self.user_model.entitlements if _.tag_id in project_model.resource_tags
        ]
        permissions = []
        for entitlement in filtered_entitlements:
            project_permissions = [_ for _ in entitlement.permissions if "project_" in _]
            permissions.extend(project_permissions)
        project_permissions = list(set(permissions))
        project_permissions.sort()
        return project_permissions

    @raise_exception("Failed to retrieve project authorization mapping.")
    def get_project_authorization_mapping(self) -> Dict[str, List[str]]:
        """
        Retrieves a mapping of project ids to their permissions for authorized projects.

        This method iterates over the authorized project id list and for each project id, it calls the
        get_project_permissions method and maps the project id to the returned permissions.

        Returns:
            Dict[str, List[str]]: A mapping of project ids to their permissions for authorized projects.

        Raises:
            Exception: If there is a failure in retrieving the project authorization mapping.
        """
        return {
            project_id: self.get_project_permissions(
                project_id=project_id,
                project_models=self.authorized_project_models,
            )
            for project_id in self.authorized_project_id_list
        }

    @raise_exception("Failed to retrieve project entitlement mapping.")
    def get_project_entitlement_mapping(self) -> Dict[str, List[str]]:
        """
        Retrieves a mapping of project ids to their permissions for entitled projects.

        This method iterates over the entitled project id list and for each project id, it calls the
        get_project_permissions method and maps the project id to the returned permissions.

        Returns:
            Dict[str, List[str]]: A mapping of project ids to their permissions for entitled projects.

        Raises:
            Exception: If there is a failure in retrieving the project entitlement mapping.
        """
        return {
            project_id: self.get_project_permissions(
                project_id=project_id,
                project_models=self.entitled_project_models,
            )
            for project_id in self.entitled_project_id_list
        }

    @raise_exception("Failed to verify resource tags authorization.")
    def verify_resource_tags(
        self,
        resource_tags: List[str],
        disable_exception=False,
    ) -> bool:
        """
        Verifies if the user is authorized for the given resource tags.

        If the user is a superuser, it returns True. If the user is not a superuser, it checks if all
        the given resource tags are in the user's authorized tag id list. If they are not, it either
        returns False or raises a BadRequest exception depending on the disable_exception flag.

        Args:
            resource_tags (List[str]): The resource tags to verify authorization for.
            disable_exception (bool, optional): If set to True, the method will return False instead of
                                                raising an exception when the user is not authorized.
                                                Defaults to False.

        Returns:
            bool: True if the user is authorized for the given resource tags, False otherwise.

        Raises:
            BadRequest: If the user is not authorized for the given resource tags and disable_exception
                        is set to False.
        """
        if self.user_model.is_superuser:
            return True
        if any(_ not in self.authorized_tag_id_list for _ in resource_tags):
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to verify user id list authorization.")
    def verify_user_id_list(
        self,
        user_id_list: List[str],
        disable_exception=False,
    ) -> bool:
        """
        Verifies if the user is authorized for the given user ids.

        If the user is a superuser, it returns True. If the user is not a superuser, it checks if all
        the given user ids are in the user's authorized user id list. If they are not, it either returns
        False or raises a BadRequest exception depending on the disable_exception flag.

        Args:
            user_id_list (List[str]): The user ids to verify authorization for.
            disable_exception (bool, optional): If set to True, the method will return False instead of
                                                raising an exception when the user is not authorized.
                                                Defaults to False.

        Returns:
            bool: True if the user is authorized for the given user ids, False otherwise.

        Raises:
            BadRequest: If the user is not authorized for the given user ids and disable_exception is
                        set to False.
        """
        if self.user_model.is_superuser:
            return True
        if any(_ not in self.authorized_user_id_list for _ in user_id_list):
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to verify project id authorization.")
    def verify_project_id(
        self,
        project_id: str,
        disable_exception=False,
    ) -> bool:
        """
        Verifies if the user is authorized for the given project id.

        If the user is a superuser, it returns True. If the user is not a superuser, it checks if the
        given project id is in the user's authorized project id list. If it is not, it either returns
        False or raises a BadRequest exception depending on the disable_exception flag.

        Args:
            project_id (str): The id of the project to verify authorization for.
            disable_exception (bool, optional): If set to True, the method will return False instead of
                                                raising an exception when the user is not authorized.
                                                Defaults to False.

        Returns:
            bool: True if the user is authorized for the given project id, False otherwise.

        Raises:
            BadRequest: If the user is not authorized for the given project id and disable_exception
                        is set to False.
        """
        if self.user_model.is_superuser:
            return True
        if project_id not in self.authorized_project_id_list:
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to verify project id list authorization.")
    def verify_project_id_list(
        self,
        project_id_list: List[str],
        disable_exception=False,
    ) -> bool:
        """
        Verifies if the user is authorized for the given list of project ids.

        If the user is a superuser, it returns True. If the user is not a superuser, it checks if all
        the given project ids are in the user's authorized project id list. If they are not, it either
        returns False or raises a BadRequest exception depending on the disable_exception flag.

        Args:
            project_id_list (List[str]): The list of project ids to verify authorization for.
            disable_exception (bool, optional): If set to True, the method will return False instead of
                                                raising an exception when the user is not authorized.
                                                Defaults to False.

        Returns:
            bool: True if the user is authorized for all the given project ids, False otherwise.

        Raises:
            BadRequest: If the user is not authorized for the given project ids and disable_exception
                        is set to False.
        """
        if self.user_model.is_superuser:
            return True
        if any(_ not in self.authorized_project_id_list for _ in project_id_list):
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to verify project field authorization.")
    @verify_params(key_list=["project_id"])
    def verify_project_field_authorization(
        self,
        project_id: str,
        disable_exception=False,
    ) -> bool:
        """
        Verifies the field authorization for the provided project id.

        This method verifies the project id. If the verification is successful, it returns True.
        Otherwise, it retrieves the project permissions from the project entitlement mapping using the
        project id. It then checks if any of the project permissions are in the field permissions. If
        not, and if disable_exception is False, it raises a BadRequest exception. Otherwise, it returns
        True if any of the project permissions are in the field permissions, and False otherwise.

        Args:
            project_id (str): The project id to verify the field authorization for.
            disable_exception (bool, optional): Whether to disable raising exceptions. Defaults to False.

        Returns:
            bool: True if the field authorization is verified, False otherwise.

        Raises:
            BadRequest: If the field authorization is not verified and disable_exception is False.
        """
        if self.verify_project_id(project_id=project_id, disable_exception=True):
            return True
        project_permissions = self.project_entitlement_mapping.get(project_id, [])
        if not any(_ in self.field_permissions for _ in project_permissions):
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to verify standalone authorization.")
    def verify_standalone_authorization(
        self,
        disable_exception=False,
    ) -> bool:
        """
        Verifies standalone authorization.

        This method checks if the user is a superuser. If so, it returns True. Otherwise, it checks if
        any of the user's permissions are in the unique permissions. If not, and if disable_exception is
        False, it raises a BadRequest exception. Otherwise, it returns True if any of the user's
        permissions are in the unique permissions, and False otherwise.

        Args:
            disable_exception (bool, optional): Whether to disable raising exceptions. Defaults to False.

        Returns:
            bool: True if the standalone authorization is verified, False otherwise.

        Raises:
            BadRequest: If the standalone authorization is not verified and disable_exception is False.
        """
        if self.user_model.is_superuser:
            return True
        if not any(p in self.unique_permissions for p in self.permissions):
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to verify standalone field authorization.")
    def verify_standalone_field_authorization(
        self,
        disable_exception=False,
    ) -> bool:
        """
        Verifies standalone field authorization.

        This method first verifies standalone authorization. If standalone authorization
        is verified, it returns True. If not, it checks if any of the unique permissions
        are in the field permissions. If none of the unique permissions are in the field
        permissions and disable_exception is False, it raises a BadRequest exception.
        Otherwise, it returns False if disable_exception is True or True otherwise.

        Args:
            disable_exception (bool, optional): Whether to disable raising exceptions.
                                                Defaults to False.

        Returns:
            bool: True if standalone field authorization is verified, False otherwise.

        Raises:
            BadRequest: If none of the unique permissions are in the field permissions
                        and disable_exception is False.
        """
        if self.verify_standalone_authorization(disable_exception=True):
            return True
        if not any(_ in self.field_permissions for _ in self.unique_permissions):
            if disable_exception:
                return False
            raise BadRequest(f"You do not have permission to complete this operation.")
        return True

    @raise_exception("Failed to check project field authorization.")
    @verify_params(key_list=["project_id", "field_key"])
    def check_project_field_authorization(
        self,
        project_id: str,
        field_key: str,
    ) -> bool:
        """
        Checks if a project field is authorized.

        This method retrieves the field permission for the provided field key from the
        field permissions. If no field permission is found, it returns False. It then
        verifies the project ID. If the project ID is verified, it returns True. It then
        retrieves the project permissions for the project ID from the project entitlement
        mapping. If the field permission is not in the project permissions, it returns
        False. Otherwise, it returns True.

        Args:
            project_id (str): The ID of the project to check the field authorization for.
            field_key (str): The key of the field to check the authorization for.

        Returns:
            bool: True if the project field is authorized, False otherwise.

        Raises:
            Exception: If an error occurs while checking the project field authorization.
        """
        field_permission = next(
            (_ for _ in self.field_permissions if _.split(".")[-2] == field_key), None
        )
        if not field_permission:
            return False
        if self.verify_project_id(project_id=project_id, disable_exception=True):
            return True
        project_permissions = self.project_entitlement_mapping.get(project_id, [])
        if field_permission not in project_permissions:
            return False
        return True

    @raise_exception("Failed to check standalone field authorization.")
    @verify_params(key_list=["field_key"])
    def check_standalone_field_authorization(
        self,
        field_key: str,
    ) -> bool:
        """
        Checks if a standalone field is authorized.

        This method retrieves the field permission for the provided field key from the
        field permissions. If no field permission is found, it returns False. It then
        verifies standalone authorization. If standalone authorization is verified, it
        returns True. If the field permission is not in the unique permissions, it returns
        False. Otherwise, it returns True.

        Args:
            field_key (str): The key of the field to check the authorization for.

        Returns:
            bool: True if the standalone field is authorized, False otherwise.

        Raises:
            Exception: If an error occurs while checking the standalone field authorization.
        """
        field_permission = next(
            (_ for _ in self.field_permissions if _.split(".")[-2] == field_key), None
        )
        if not field_permission:
            return False
        if self.verify_standalone_authorization(disable_exception=True):
            return True
        if field_permission not in self.unique_permissions:
            return False
        return True

    @raise_exception("Failed to retrieve authorized resource.")
    def get_authorized_resource(
        self,
        resource: Any,
        superuser_resource=None,
    ) -> Any:
        """
        Retrieves the authorized resource.

        If the user is a superuser, it returns the superuser resource if provided, otherwise it returns
        the resource. If the user is not a superuser, it checks if the user has any of the permissions.
        If the user does not have any of the permissions, it raises a BadRequest exception. Otherwise,
        it returns the resource.

        Args:
            resource (Any): The resource to authorize.
            superuser_resource (Any, optional): The resource to return if the user is a superuser.
                                                Defaults to None.

        Returns:
            Any: The authorized resource.

        Raises:
            BadRequest: If the user is not a superuser and does not have any of the permissions.
        """
        if self.user_model.is_superuser:
            return superuser_resource if superuser_resource else resource
        if not any(p in self.unique_permissions for p in self.permissions):
            raise BadRequest(f"You do not have permission to complete this operation.")
        return resource

    @raise_exception("Failed to retrieve authorized tag resource.")
    def get_authorized_tag_resource(
        self,
        resource_tags: List[str],
        resource: Any,
        superuser_resource=None,
    ) -> Any:
        """
        Retrieves the authorized tag resource.

        If the user is a superuser, it returns the superuser resource if provided, otherwise it returns
        the resource. If the user is not a superuser, it checks if all the resource tags are in the
        user's authorized tag id list. If they are not, it raises a BadRequest exception. Otherwise, it
        returns the resource.

        Args:
            resource_tags (List[str]): The resource tags to authorize.
            resource (Any): The resource to authorize.
            superuser_resource (Any, optional): The resource to return if the user is a superuser.
                                                Defaults to None.

        Returns:
            Any: The authorized tag resource.

        Raises:
            BadRequest: If the user is not a superuser and not all the resource tags are in the user's
                        authorized tag id list.
        """
        if self.user_model.is_superuser:
            return superuser_resource if superuser_resource else resource
        if any(_ not in self.authorized_tag_id_list for _ in resource_tags):
            raise BadRequest(f"You do not have permission to complete this operation.")
        return resource

    @raise_exception("Failed to retrieve authorized project resource.")
    @verify_params(key_list=["project_id"])
    def get_authorized_project_resource(
        self,
        project_id: str,
        resource: Any,
    ) -> Any:
        """
        Retrieves the authorized project resource.

        If the user is a superuser, it returns the resource. If the user is not a superuser, it checks
        if the given project id is in the user's authorized project id list. If it is not, it raises a
        BadRequest exception. Otherwise, it returns the resource.

        Args:
            project_id (str): The id of the project to authorize.
            resource (Any): The resource to authorize.

        Returns:
            Any: The authorized project resource.

        Raises:
            BadRequest: If the user is not a superuser and the given project id is not in the user's
                        authorized project id list.
        """
        if self.user_model.is_superuser:
            return resource
        if project_id not in self.authorized_project_id_list:
            raise BadRequest(f"You do not have permission to complete this operation.")
        return resource
