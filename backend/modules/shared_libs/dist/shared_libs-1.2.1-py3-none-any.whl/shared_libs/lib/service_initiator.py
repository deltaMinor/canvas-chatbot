import redis
from celery import Celery

from .. import lib_config
from ..decorators.exception import raise_exception
from ..domain.resource_tag.service.service import ResourceTagService
from ..domain.token.service.redis_service import TokenRedisService
from ..infrastructure.producer.service import Producer
from ..infrastructure.redis_repository.service import RedisRepository
from ..infrastructure.remote_repository.service import RemoteRepository
from ..lib.resource_tag_manager import ResourceTagManager
from ..models.base_models import ProducerDataModel
from ..producers.authentication_producer import AuthenticationProducer
from ..producers.producer_data import (
    producer_data_authentication,
    producer_data_resource_tag,
)

REDIS_HOSTNAME = lib_config.REDIS_HOSTNAME
REDIS_PORT = lib_config.REDIS_PORT
REDIS_TOKEN_EXPIRY = lib_config.REDIS_TOKEN_EXPIRY


class ServiceInitiator:
    def __init__(self, celery_app: Celery):
        self.celery_app = celery_app

    @property
    def auth_producer(self):
        return self.get_auth_producer_instance()

    @raise_exception("Failed to initialize auth producer.")
    def get_auth_producer_instance(self):
        producer = Producer(
            producer_data_model=ProducerDataModel(
                **producer_data_authentication,
            ),
            celery_app=self.celery_app,
        )
        resource_tag_service = ResourceTagService(
            repository=RemoteRepository(
                producer=Producer(
                    producer_data_model=ProducerDataModel(
                        **producer_data_resource_tag,
                    ),
                    celery_app=self.celery_app,
                ),
            ),
        )
        resource_tag_manager = ResourceTagManager(
            resource_tag_service=resource_tag_service,
            redis_repository=RedisRepository(
                redis_client=redis.Redis(
                    host=REDIS_HOSTNAME,
                    port=REDIS_PORT,
                ),
            ),
        )
        token_redis_service = TokenRedisService(
            redis_repository=RedisRepository(
                redis_client=redis.Redis(
                    host=REDIS_HOSTNAME,
                    port=REDIS_PORT,
                ),
                default_expiry=REDIS_TOKEN_EXPIRY,
            )
        )
        return AuthenticationProducer(
            producer=producer,
            resource_tag_manager=resource_tag_manager,
            token_redis_service=token_redis_service,
        )
