import base64
import io

from django.core.files.uploadedfile import UploadedFile


class FileManager:
    def __init__(self):
        pass

    @staticmethod
    def get_file_bytes(decoded_file: str) -> io.BytesIO:
        """Converts a decoded string to a BytesIO object.

        This method takes a decoded string, encodes it back into bytes, and then converts it into a BytesIO object.

        Args:
            decoded_file (str): The decoded string to convert.

        Returns:
            io.BytesIO: The BytesIO object representation of the decoded string.
        """
        encoded_file = decoded_file.encode("utf-8")
        return io.BytesIO(encoded_file)

    @staticmethod
    def get_decoded_file(file: UploadedFile) -> str:
        """Converts an uploaded file to a base64 encoded string.

        This method reads the uploaded file in chunks, concatenates the chunks into a bytestring, and then converts the bytestring into a base64 encoded string.

        Args:
            file (UploadedFile): The uploaded file to convert.

        Returns:
            str: The base64 encoded string representation of the uploaded file.
        """
        bytestring = b""
        for chunk in file.chunks(chunk_size=1024):
            bytestring += chunk
        return base64.b64encode(bytestring).decode("utf-8")
