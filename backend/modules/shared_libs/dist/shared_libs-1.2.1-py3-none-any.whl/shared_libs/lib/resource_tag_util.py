from typing import List

from ..decorators.exception import raise_exception
from ..decorators.validation import verify_params
from ..logger.app_logger import logger
from ..models.database_models import ResourceTagTreeModel


class ResourceTagUtil:
    def __init__(
        self,
        resource_tag_tree_models: List[ResourceTagTreeModel],
    ):
        self.resource_tag_tree_models = resource_tag_tree_models

    @raise_exception("Failed to retrieve tag name.")
    @verify_params(key_list=["tag_id"])
    def get_tag_name(self, tag_id: str):
        res = next(
            (_.tag_name for _ in self.resource_tag_tree_models if _.tag_id == tag_id),
            "",
        )
        return res

    @raise_exception("Failed to retrieve root tag id.")
    @verify_params(key_list=["tag_id"])
    def get_root_tag_id(self, tag_id: str):
        resource_tag_tree_model = next(
            (_ for _ in self.resource_tag_tree_models if _.tag_id == tag_id),
            None,
        )
        if not resource_tag_tree_model or not len(resource_tag_tree_model.parent_nodes):
            return ""
        return resource_tag_tree_model.parent_nodes[-1]

    @raise_exception("Failed to retrieve root tag name.")
    @verify_params(key_list=["tag_id"])
    def get_root_tag_name(self, tag_id: str):
        root_tag_id = self.get_root_tag_id(
            tag_id=tag_id,
        )
        if not root_tag_id:
            return ""
        return self.get_tag_name(
            tag_id=root_tag_id,
        )
