import datetime
from typing import List

from ...decorators.exception import raise_exception
from ...logger.app_logger import logger
from ...models.attack import AttackPattern
from ...types.enum import AttackObjectTypeLabel
from .constants import TYPE_MAPPING


class AttackFormatter:
    @staticmethod
    @raise_exception("Failed to reformat attack type.")
    def replace_type(attack_docs: List[AttackPattern]):
        for attack_doc in attack_docs:
            if attack_doc.type in TYPE_MAPPING:
                attack_doc.type = TYPE_MAPPING.get(attack_doc.type)
            # else:
            #     logger.debug(f"type {attack_doc.type} not found in TYPE_MAPPING.")

            if (
                attack_doc.type == AttackObjectTypeLabel.technique.value
                and attack_doc.xMitreIsSubtechnique
            ):
                attack_doc.type = AttackObjectTypeLabel.subtechnique.value

            if (
                attack_doc.type == AttackObjectTypeLabel.relationship.value
                and attack_doc.relationshipType == "uses"
                and "attack-pattern" in (attack_doc.targetRef or "")
            ):
                attack_doc.type = AttackObjectTypeLabel.procedure.value

    @staticmethod
    @raise_exception("Failed to reformat attack refs.")
    def replace_refs(attack_docs: List[AttackPattern]):
        # to replace the "type" field before using this function

        identities = {
            attack_doc.id: attack_doc.name
            for attack_doc in attack_docs
            if attack_doc.type == AttackObjectTypeLabel.identity.value
        }

        for attack_doc in attack_docs:
            if (
                attack_doc.createdByRef
                and attack_doc.type != AttackObjectTypeLabel.identity.value
                and attack_doc.createdByRef in identities
            ):
                attack_doc.createdByRef = identities[attack_doc.createdByRef]

            if (
                attack_doc.xMitreModifiedByRef
                and attack_doc.type != AttackObjectTypeLabel.identity.value
                and attack_doc.xMitreModifiedByRef in identities
            ):
                attack_doc.xMitreModifiedByRef = identities[attack_doc.xMitreModifiedByRef]

    @staticmethod
    @raise_exception("Failed to reformat attack object marking refs.")
    def replace_object_marking_refs(attack_docs: List[AttackPattern]):
        marking_definitions = {
            attack_doc.id: attack_doc.definition.statement
            for attack_doc in attack_docs
            if attack_doc.type == AttackObjectTypeLabel.markingDefinition.value
        }

        for attack_doc in attack_docs:
            if attack_doc.objectMarkingRefs:
                attack_doc.objectMarkingRefs = [
                    (marking_definitions.get(ref, "")) for ref in attack_doc.objectMarkingRefs
                ]

    @staticmethod
    @raise_exception("Failed to parse date time in attack formatter.")
    def parse_date_time(value):
        # Use %B to format the month as a full name
        # formatted_time = date_obj.strftime("%H:%M:%S.%f")[:-3] + " UTC"
        try:
            date_obj = datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%S.%fZ")
            return f"{date_obj.strftime('%d %b %Y')}"
        except Exception:
            pass

        try:
            date_obj = datetime.datetime.strptime(value, "%d %b %Y")
            return f"{date_obj.strftime('%d %b %Y')}"
        except Exception:
            pass

        logger.error(f"Failed to parse date time: {value}")
        return ""

    @raise_exception("Failed to reformat attack date time.")
    def replace_date_time(self, attack_docs: List[AttackPattern]):
        date_time_properties = ["created", "modified", "firstSeen", "lastSeen"]
        for attack_doc in attack_docs:
            for key, val in attack_doc.model_dump().items():
                if val and (key in date_time_properties):
                    attack_doc.__dict__.update({key: self.parse_date_time(val)})
                continue

    @staticmethod
    @raise_exception("Failed to reformat attack object.")
    def parse_objects(attack_docs: List[AttackPattern]):
        for attack_doc in attack_docs:
            # techniques map into tactics by use of their killChainPhases property
            if attack_doc.killChainPhases:
                tactics = []
                for kill_chain in attack_doc.killChainPhases:
                    tactics.append(kill_chain.phaseName)
                attack_doc.tactics = tactics
                attack_doc.killChainPhases = None
            if attack_doc.xMitreDomains:
                domain_dict = {
                    "ics-attack": "ICS",
                    "mobile-attack": "Mobile",
                    "enterprise-attack": "Enterprise",
                }
                domain_dict_set = set(domain_dict.keys()).union(set(domain_dict.values()))
                if any(_ not in domain_dict_set for _ in attack_doc.xMitreDomains):
                    logger.error(
                        f"[{attack_doc.id}] attack_doc object parsing failed. There are one of more unrecognised xMitreDomain."
                    )
                    return
                attack_doc.xMitreDomains = [domain_dict.get(_, _) for _ in attack_doc.xMitreDomains]
