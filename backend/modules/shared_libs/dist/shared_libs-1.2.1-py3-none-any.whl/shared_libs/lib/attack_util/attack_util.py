from functools import cached_property
from typing import Any, List, Mapping

from ...decorators.exception import raise_exception
from ...exceptions.exceptions import AttributeValueError
from ...logger.app_logger import logger
from ...models.attack import AttackDocsModel, AttackPattern
from ...types.enum import AttackDomain, AttackObjectType, AttackObjectTypeLabel
from .attack_formatter import AttackFormatter


class AttackUtil:
    def __init__(self, attack_docs_dict: dict):
        logger.debug("Initializing attack utils ...")
        self.attack_docs_model = AttackDocsModel(**attack_docs_dict)
        self.attack_ics_docs_formatted
        self.attack_mobile_docs_formatted
        self.attack_enterprise_docs_formatted
        self.attack_docs_formatted
        self.parsed_attack_docs
        self.attack_scenarios_info
        logger.debug("Attack utils initialized.")

    @raise_exception("Failed to format ICS attack documents.")
    def get_attack_ics_docs_formatted(
        self, attack_docs: List[AttackPattern]
    ) -> List[AttackPattern]:
        return self.format_attack_database(attack_docs)

    @cached_property
    def attack_ics_docs_formatted(self):
        logger.debug(f"Rebuilding property attack_ics_docs_formatted ...")
        return self.get_attack_ics_docs_formatted(
            self.attack_docs_model.attack_ics_docs,
        )

    @raise_exception("Failed to format mobile attack documents.")
    def get_attack_mobile_docs_formatted(self, attack_docs: List[AttackPattern]):
        return self.format_attack_database(attack_docs)

    @cached_property
    def attack_mobile_docs_formatted(self):
        logger.debug(f"Rebuilding property attack_mobile_docs_formatted ...")
        return self.get_attack_mobile_docs_formatted(
            self.attack_docs_model.attack_mobile_docs,
        )

    @raise_exception("Failed to format enterprise attack documents.")
    def get_attack_enterprise_docs_formatted(self, attack_docs: List[AttackPattern]):
        return self.format_attack_database(attack_docs)

    @cached_property
    def attack_enterprise_docs_formatted(self):
        logger.debug(f"Rebuilding property attack_enterprise_docs_formatted ...")
        return self.get_attack_enterprise_docs_formatted(
            self.attack_docs_model.attack_enterprise_docs,
        )

    @raise_exception("Failed to format attack documents.")
    def get_attack_docs_formatted(self):
        return (
            self.attack_ics_docs_formatted
            + self.attack_mobile_docs_formatted
            + self.attack_enterprise_docs_formatted
        )

    @cached_property
    def attack_docs_formatted(self):
        logger.debug(f"Rebuilding property attack_docs_formatted ...")
        return self.get_attack_docs_formatted()

    @staticmethod
    @raise_exception("Failed to get attack objects by type.")
    def get_attack_objects_by_type(
        attack_docs: List[AttackPattern],
        obj_type: str,
        to_dict=False,
    ) -> List[AttackPattern] | List[Mapping[str, Any]]:
        attack_doc_dict = {doc.id: doc for doc in attack_docs if doc.type == obj_type}
        attack_doc_models = list(attack_doc_dict.values())

        logger.debug(
            f"Processed {len(attack_docs)} attack_docs, {len(attack_doc_models)} objects of type <{obj_type}> found."
        )
        if to_dict:
            return [_.model_dump() for _ in attack_doc_models]
        return attack_doc_models

    @raise_exception("Failed to get attack objects.")
    def get_attack_objects(self, attack_docs: List[AttackPattern]) -> List[AttackPattern]:
        seen_ids = set()
        return [obj for obj in attack_docs if obj.id not in seen_ids and not seen_ids.add(obj.id)]

    @raise_exception("Failed to format attack database.")
    def format_attack_database(self, attack_docs: List[AttackPattern]) -> List[AttackPattern]:
        attack_formatter = AttackFormatter()
        attack_formatter.replace_type(attack_docs)
        attack_formatter.replace_refs(attack_docs)
        attack_formatter.replace_object_marking_refs(attack_docs)
        attack_formatter.replace_date_time(attack_docs)
        attack_formatter.parse_objects(attack_docs)
        return attack_docs

    @raise_exception("Failed to get formatted attack objects.")
    def get_attack_objects_formatted(self, attack_docs: List[AttackPattern]) -> List[AttackPattern]:
        attack_objects = self.get_attack_objects(attack_docs)
        return self.format_attack_database(attack_objects)

    @staticmethod
    @raise_exception("Failed to get mitigation objects details.")
    def get_mitigation_objects_details(attack_docs: List[AttackPattern]):
        res = {}
        for attack_doc in attack_docs:
            if not len(attack_doc.externalReferences):
                continue
            res[attack_doc.id] = {
                "externalId": attack_doc.externalReferences[0].externalId,
                "name": attack_doc.name,
                "description": attack_doc.description,
            }
        return res

    @staticmethod
    @raise_exception("Failed to get ID to externalId mapping.")
    def get_id_to_externalId_mapping(attack_docs: List[AttackPattern]):
        # including sub techniques objects
        return {
            attack_doc.id: attack_doc.externalReferences[0].externalId
            for attack_doc in attack_docs
            if len(attack_doc.externalReferences)
        }

    @staticmethod
    @raise_exception("Failed to get relationship mitigates attack info.")
    def get_relationship_mitigates_attack_info(attack_docs: List[AttackPattern]):
        res = []
        for attack_doc in attack_docs:
            checkActive = (
                attack_doc.xMitreDeprecated != True
                if attack_doc.xMitreDeprecated is not None
                else True
            )
            check = (
                checkActive
                and attack_doc.relationshipType == "mitigates"
                and "attack-pattern" in (attack_doc.targetRef or "")
            )
            if check:
                # only active relationships are considered
                output = {
                    "techniqueId": attack_doc.targetRef,
                    "relationshipId": attack_doc.id,
                    "mitigationId": attack_doc.sourceRef,
                    "mitigationDescription": attack_doc.description,
                }
                res.append(output)
        return res

    @cached_property
    def attack_scenarios_info(self):
        logger.debug(f"Rebuilding property attack_scenarios_info ...")
        return self.get_attack_scenarios_info()

    @raise_exception("Failed to get attack scenarios info")
    def get_attack_scenarios_info(self):
        attack_docs = self.attack_docs_model.attack_docs
        if not attack_docs or not len(attack_docs):
            raise AttributeValueError("No attack documents found in the provided dictionary.")
        attack_objects = self.get_attack_objects_formatted(attack_docs)

        techniques_all = self.get_attack_objects_by_type(
            attack_objects,
            AttackObjectTypeLabel.technique.value,
        ) + self.get_attack_objects_by_type(
            attack_objects,
            AttackObjectTypeLabel.subtechnique.value,
        )
        mitigation_objects = self.get_attack_objects_by_type(
            attack_objects,
            AttackObjectTypeLabel.mitigation.value,
        )
        relationship_objects = self.get_attack_objects_by_type(
            attack_objects,
            AttackObjectTypeLabel.relationship.value,
        )

        id_mapping = self.get_id_to_externalId_mapping(techniques_all)

        mitigation_objects_details = self.get_mitigation_objects_details(mitigation_objects)

        attack_to_mitigation_mapping = self.get_relationship_mitigates_attack_info(
            relationship_objects
        )

        res = {}

        for attack_doc in techniques_all:
            externalId = id_mapping[attack_doc.id]
            if attack_doc.id not in res:
                res[externalId] = {
                    "keyRisk": attack_doc.name,
                    "recommendedMitigationMeasures": [],
                }

        for obj in attack_to_mitigation_mapping:
            _id = obj["techniqueId"]
            externalId = id_mapping[_id]
            mitigationId = obj["mitigationId"]
            mitigationDescription = obj["mitigationDescription"]

            mitigation_measure = {
                "id": obj["relationshipId"],
                "header": mitigation_objects_details[mitigationId]["name"],
                "measure": mitigationDescription,
            }

            res[externalId]["recommendedMitigationMeasures"].append(mitigation_measure)

        return res

    @cached_property
    def parsed_attack_docs(self):
        logger.debug(f"Rebuilding property parsed_attack_docs ...")
        return self.get_parsed_attack_docs()

    @raise_exception("Failed to parse attack docs.")
    def get_parsed_attack_docs(self):
        data = {
            AttackObjectType.tactic.value: {
                AttackDomain.ics.value: self.get_attack_objects_by_type(
                    self.attack_ics_docs_formatted,
                    AttackObjectTypeLabel.tactic.value,
                    to_dict=True,
                ),
                AttackDomain.mobile.value: self.get_attack_objects_by_type(
                    self.attack_mobile_docs_formatted,
                    AttackObjectTypeLabel.tactic.value,
                    to_dict=True,
                ),
                AttackDomain.enterprise.value: self.get_attack_objects_by_type(
                    self.attack_enterprise_docs_formatted,
                    AttackObjectTypeLabel.tactic.value,
                    to_dict=True,
                ),
            },
            AttackObjectType.technique.value: {
                AttackDomain.ics.value: self.get_attack_objects_by_type(
                    self.attack_ics_docs_formatted,
                    AttackObjectTypeLabel.technique.value,
                    to_dict=True,
                ),
                AttackDomain.mobile.value: self.get_attack_objects_by_type(
                    self.attack_mobile_docs_formatted,
                    AttackObjectTypeLabel.technique.value,
                    to_dict=True,
                ),
                AttackDomain.enterprise.value: self.get_attack_objects_by_type(
                    self.attack_enterprise_docs_formatted,
                    AttackObjectTypeLabel.technique.value,
                    to_dict=True,
                ),
            },
            AttackObjectType.subtechnique.value: {
                AttackDomain.ics.value: self.get_attack_objects_by_type(
                    self.attack_ics_docs_formatted,
                    AttackObjectTypeLabel.subtechnique.value,
                    to_dict=True,
                ),
                AttackDomain.mobile.value: self.get_attack_objects_by_type(
                    self.attack_mobile_docs_formatted,
                    AttackObjectTypeLabel.subtechnique.value,
                    to_dict=True,
                ),
                AttackDomain.enterprise.value: self.get_attack_objects_by_type(
                    self.attack_enterprise_docs_formatted,
                    AttackObjectTypeLabel.subtechnique.value,
                    to_dict=True,
                ),
            },
            AttackObjectType.dataSource.value: self.get_attack_objects_by_type(
                self.attack_docs_formatted,
                AttackObjectTypeLabel.dataSource.value,
                to_dict=True,
            ),
            AttackObjectType.mitigation.value: {
                AttackDomain.ics.value: self.get_attack_objects_by_type(
                    self.attack_ics_docs_formatted,
                    AttackObjectTypeLabel.mitigation.value,
                    to_dict=True,
                ),
                AttackDomain.mobile.value: self.get_attack_objects_by_type(
                    self.attack_mobile_docs_formatted,
                    AttackObjectTypeLabel.mitigation.value,
                    to_dict=True,
                ),
                AttackDomain.enterprise.value: self.get_attack_objects_by_type(
                    self.attack_enterprise_docs_formatted,
                    AttackObjectTypeLabel.mitigation.value,
                    to_dict=True,
                ),
            },
            AttackObjectType.group.value: self.get_attack_objects_by_type(
                self.attack_docs_formatted,
                AttackObjectTypeLabel.group.value,
                to_dict=True,
            ),
            AttackObjectType.software.value: self.get_attack_objects_by_type(
                self.attack_docs_formatted,
                AttackObjectTypeLabel.software.value,
                to_dict=True,
            ),
            AttackObjectType.campaign.value: self.get_attack_objects_by_type(
                self.attack_docs_formatted,
                AttackObjectTypeLabel.campaign.value,
                to_dict=True,
            ),
        }

        return data
