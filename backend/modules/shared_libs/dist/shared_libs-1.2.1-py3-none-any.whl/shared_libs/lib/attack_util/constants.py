from ...types.enum import AttackObjectTypeLabel

TYPE_MAPPING = {
    "attack-pattern": AttackObjectTypeLabel.technique.value,
    "campaign": AttackObjectTypeLabel.campaign.value,
    "course-of-action": AttackObjectTypeLabel.mitigation.value,
    "identity": AttackObjectTypeLabel.identity.value,
    "intrusion-set": AttackObjectTypeLabel.group.value,
    "malware": AttackObjectTypeLabel.software.value,
    "marking-definition": AttackObjectTypeLabel.markingDefinition.value,
    "relationship": AttackObjectTypeLabel.relationship.value,
    "tool": AttackObjectTypeLabel.software.value,
    "x-mitre-collection": AttackObjectTypeLabel.collection.value,
    "x-mitre-data-component": AttackObjectTypeLabel.dataComponent.value,
    "x-mitre-data-source": AttackObjectTypeLabel.dataSource.value,
    "x-mitre-matrix": AttackObjectTypeLabel.matrix.value,
    "x-mitre-tactic": AttackObjectTypeLabel.tactic.value,
}
