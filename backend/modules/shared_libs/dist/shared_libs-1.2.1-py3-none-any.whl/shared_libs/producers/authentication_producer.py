from functools import cached_property
from typing import Any, List, Mapping, Self

from rest_framework.request import Request

from ..decorators.exception import raise_exception
from ..decorators.validation import verify_params
from ..domain.token.service.redis_service import TokenRedisService
from ..exceptions.api_exceptions import Unauthorized
from ..exceptions.exceptions import HeaderKeyError, HeaderValueError
from ..infrastructure.producer.service import Producer
from ..lib.resource_tag_manager import ResourceTagManager
from ..logger.app_logger import logger
from ..models.base_models import UserInfoModel
from ..models.database_models import AuthenticationModel, ResourceTagTreeModel
from ..types.enum import JWT, TokenType


class AuthenticationProducer:

    token_type: str = TokenType.login.value
    authentication_model: AuthenticationModel = None
    user_info: Mapping[str, Any] = None

    def __init__(
        self,
        producer: Producer,
        resource_tag_manager: ResourceTagManager,
        token_redis_service: TokenRedisService,
    ):
        self.producer = producer
        self.resource_tag_manager = resource_tag_manager
        self.token_redis_service = token_redis_service

    @property
    def resource_tag_tree_models(self) -> List[ResourceTagTreeModel]:
        return self.resource_tag_manager.resource_tag_tree_models

    @raise_exception("Failed to delete all tokens for the user.")
    @verify_params(key_list=["user_id"])
    def delete_all_tokens(self, user_id: str) -> None:
        """
        Deletes all tokens associated with a user.

        This method will delete all tokens in the database associated with the user specified by the 'user_id' parameter.

        Args:
            user_id (str): The ID of the user whose tokens should be deleted.
        """
        self.producer.get_task_value(
            task_type="delete_all_tokens",
            task_body={"user_id": user_id},
        )

    @raise_exception("Failed to retrieve authentication model from database.")
    @verify_params(key_list=["encoded_token"])
    def get_authentication_model_from_db(self, encoded_token: str) -> AuthenticationModel | None:
        """
        Retrieves the authentication model from the database.

        This method retrieves the authentication model from the database using the encoded token.
        If the model does not exist, it returns None.
        If the model exists, it returns the AuthenticationModel instance.

        Args:
            encoded_token (str): The encoded token used to retrieve the authentication model.

        Returns:
            AuthenticationModel | None: The authentication model if it exists, None otherwise.

        Raises:
            Exception: If the retrieval of the authentication model from the database fails.
        """
        logger.debug("Retrieving authentication model dict from database.")
        res = self.producer.get_task_value(
            task_type="verify_token",
            task_body={
                "encoded_token": encoded_token,
                "token_type": self.token_type,
            },
            raise_if_not_found=True,
        )
        if not res:
            return None

        return AuthenticationModel(**res)

    @raise_exception("Failed to retrieve authentication model dict from Redis.")
    @verify_params(key_list=["encoded_token"])
    def get_authentication_model_from_redis(self, encoded_token: str) -> AuthenticationModel | None:
        """
        Retrieves the authentication model from Redis.

        This method retrieves the authentication model from Redis using the encoded token.
        If the model does not exist, it returns None.
        If the model exists, it returns the AuthenticationModel instance.

        Args:
            encoded_token (str): The encoded token used to retrieve the authentication model.

        Returns:
            AuthenticationModel | None: The authentication model if it exists, None otherwise.

        Raises:
            Exception: If the retrieval of the authentication model from Redis fails.
        """
        logger.debug("Retrieving authentication model dict from redis.")
        authentication_model_dict = self.token_redis_service.get_authentication_model_dict(
            encoded_token=encoded_token,
        )
        if authentication_model_dict is None:
            return None

        return AuthenticationModel(**authentication_model_dict)

    @raise_exception("Failed to update authentication model in Redis.")
    @verify_params(key_list=["authentication_model"])
    def update_authentication_model_in_redis(
        self,
        authentication_model: AuthenticationModel,
        **kwargs,
    ) -> None:
        """
        Updates the authentication model in Redis.

        This method checks if an existing authentication model is present in Redis. If present, it logs a warning and does not update.
        If not present, it saves the new authentication model in Redis.

        Args:
            authentication_model (AuthenticationModel): The authentication model to be updated in Redis.
            **kwargs: Arbitrary keyword arguments.

        Raises:
            Exception: If the update operation fails.
        """
        logger.debug("Updating authentication model in redis.")
        redis_model = self.get_authentication_model_from_redis(
            encoded_token=authentication_model.encoded_token
        )
        if redis_model is not None:
            logger.warn("Existing authentication model found in redis. Model is not updated.")
            return
        self.token_redis_service.save_authentication_model_in_redis(
            authentication_model=authentication_model,
        )

    @raise_exception("Failed to get encoded token from request header.")
    @verify_params(key_list=["request"])
    def get_encoded_token_from_request_header(self, request: Request) -> str:
        """
        Retrieves the encoded token from the request header.

        This method gets the 'Authorization' field from the request header and checks if it starts with 'Bearer '.
        If the 'Authorization' field is missing or does not start with 'Bearer ', an exception is raised.

        Args:
            request (Request): The request object containing the header with the encoded token.

        Returns:
            str: The encoded token.

        Raises:
            HeaderKeyError: If the 'Authorization' field is missing in the request header.
            HeaderValueError: If the 'Authorization' field does not start with 'Bearer '.
        """
        auth_header = request.META.get(JWT.authorization.value)
        if not auth_header:
            raise HeaderKeyError("Authorization header is missing.")
        if not auth_header.startswith("Bearer "):
            raise HeaderValueError("Authorization header is invalid.")
        return auth_header[7:]

    @raise_exception("Failed to retrieve authentication model.")
    @verify_params(key_list=["encoded_token"])
    def get_authentication_model(
        self,
        encoded_token: str,
        **kwargs,
    ) -> AuthenticationModel:
        """
        Retrieves the authentication model.

        This method first tries to retrieve the authentication model from Redis using the encoded token.
        If the model does not exist in Redis, it tries to retrieve it from the database.
        If the model does not exist in the database, it raises an Unauthorized exception.
        If the model is retrieved from the database, it updates the model in Redis and returns it.

        Args:
            encoded_token (str): The encoded token used to retrieve the authentication model.

        Returns:
            AuthenticationModel: The retrieved authentication model.

        Raises:
            Unauthorized: If the retrieval of the authentication model from both Redis and the database fails.
        """
        # Get decoded token from Redis
        authentication_model = self.get_authentication_model_from_redis(
            encoded_token=encoded_token,
        )
        if authentication_model:
            return authentication_model

        # Get decoded token from DB
        authentication_model = self.get_authentication_model_from_db(
            encoded_token=encoded_token,
        )
        if not authentication_model:
            raise Unauthorized("Failed to retrieve login token.")

        self.update_authentication_model_in_redis(
            authentication_model=authentication_model,
        )
        return authentication_model

    @raise_exception("Failed to verify login token.")
    @verify_params(key_list=["request"])
    def verify_login_token(self, request: Request) -> Self:
        """
        Verifies the login token.

        This method retrieves the encoded token from the request header, then retrieves the authentication model
        using the encoded token. It then retrieves the user info from the decoded token and stores it in self.user_info.

        Args:
            request (Request): The request object containing the header with the encoded token.

        Returns:
            Self: The instance of the class with updated user_info.

        Raises:
            Exception: If the verification of the login token fails.
        """
        # Get encoded_token
        encoded_token = self.get_encoded_token_from_request_header(
            request=request,
        )

        # Get decoded_token
        self.authentication_model = self.get_authentication_model(
            encoded_token=encoded_token,
        )

        # Get user_info
        self.user_info = UserInfoModel(
            **self.authentication_model.decoded_token.model_dump()
        ).model_dump()

        return self
